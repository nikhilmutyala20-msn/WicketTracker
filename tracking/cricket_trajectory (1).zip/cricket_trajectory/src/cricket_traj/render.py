"""Hawk-Eye graphics rendering: video overlay, virtual behind-stumps view, top-down pitch map, and export."""

import json
import logging
from pathlib import Path
from typing import Any, List, Optional, Tuple
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle
import numpy as np

from cricket_traj.calibration import CameraPose
from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.counterfactual import CounterfactualTrajectory
from cricket_traj.events import DeliveryEvents
from cricket_traj.fit import TrajectoryFitResult
from cricket_traj.lbw import LBWDecision, PitchingVerdict, ImpactVerdict, WicketsVerdict
from cricket_traj.tracking import TrackPoint

logger = logging.getLogger(__name__)


class HawkEyeRenderer:
    """Renders Hawk-Eye broadcast overlays, virtual 3D behind-stumps view, pitch map, and result JSON."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG

    def render_overlay_video(
        self,
        frames: List[np.ndarray],
        camera_poses: List[CameraPose],
        fit_res: TrajectoryFitResult,
        cf_traj: CounterfactualTrajectory,
        events: DeliveryEvents,
        lbw_decision: LBWDecision,
        out_path: str | Path,
        fps: float = 50.0,
    ) -> Path:
        """Renders broadcast TV graphics overlay onto the original video sequence."""
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        h, w = frames[0].shape[:2]

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(out_path), fourcc, fps, (w, h))

        # Time indices
        t_bounce = fit_res.bounce_time
        t_impact = events.impact_time

        for i, raw_frame in enumerate(frames):
            frame = raw_frame.copy()
            pose = camera_poses[i] if i < len(camera_poses) else None
            t_curr = fit_res.timestamps[0] + (i / fps)

            if pose and pose.is_valid:
                # 1. Draw blue corridor on pitch surface
                self._draw_pitch_corridor(frame, pose)

                # 2. Draw pitching circle if reached bounce time
                if t_curr >= t_bounce - 0.05:
                    self._draw_pitching_circle(frame, pose, fit_res.p_bounce)

                # 3. Draw 3D trajectory polylines
                self._draw_trajectories(
                    frame=frame,
                    pose=pose,
                    fit_res=fit_res,
                    cf_traj=cf_traj,
                    t_curr=t_curr,
                    t_bounce=t_bounce,
                    t_impact=t_impact,
                )

            # 4. Draw broadcast verdict panels in corner
            if t_curr >= t_impact - 0.05:
                self._draw_verdict_panel(frame, lbw_decision, fit_res)

            writer.write(frame)

        writer.release()
        logger.info(f"Exported overlay video to {out_path}")
        return out_path

    def _draw_pitch_corridor(self, frame: np.ndarray, pose: CameraPose):
        """Draws semi-transparent blue corridor between stump lines along the pitch."""
        w_stump = self.cfg.lbw.stump_half_width
        corridor_3d = np.array([
            [0.0, -w_stump, 0.0],
            [0.0, w_stump, 0.0],
            [20.12, w_stump, 0.0],
            [20.12, -w_stump, 0.0],
        ])
        pts_2d = pose.project(corridor_3d).astype(np.int32)
        
        overlay = frame.copy()
        cv2.fillPoly(overlay, [pts_2d], (230, 160, 40))  # Blueish cyan
        cv2.polylines(overlay, [pts_2d], isClosed=True, color=(255, 200, 80), thickness=2, lineType=cv2.LINE_AA)
        cv2.addWeighted(overlay, 0.35, frame, 0.65, 0, frame)

    def _draw_pitching_circle(self, frame: np.ndarray, pose: CameraPose, p_bounce: np.ndarray):
        """Draws glowing yellow bounce ring and label on pitch surface."""
        angles = np.linspace(0, 2 * np.pi, 32)
        radius = 0.22
        circle_3d = np.column_stack([
            p_bounce[0] + radius * np.cos(angles),
            p_bounce[1] + radius * np.sin(angles),
            np.zeros_like(angles),
        ])
        pts_2d = pose.project(circle_3d).astype(np.int32)
        center_2d = pose.project(p_bounce.reshape(1, 3))[0].astype(np.int32)

        cv2.polylines(frame, [pts_2d], isClosed=True, color=(0, 255, 255), thickness=2, lineType=cv2.LINE_AA)
        cv2.circle(frame, tuple(center_2d), 4, (0, 255, 255), -1, lineType=cv2.LINE_AA)

        # Label badge
        label = f"PITCHED {p_bounce[0]:.2f}m from stumps"
        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.50
        (tw, th), _ = cv2.getTextSize(label, font, scale, 1)
        lx = int(center_2d[0] - tw // 2)
        ly = int(center_2d[1] - 18)
        cv2.rectangle(frame, (lx - 4, ly - th - 4), (lx + tw + 4, ly + 4), (20, 20, 20), -1)
        cv2.rectangle(frame, (lx - 4, ly - th - 4), (lx + tw + 4, ly + 4), (0, 255, 255), 1)
        cv2.putText(frame, label, (lx, ly), font, scale, (255, 255, 255), 1, lineType=cv2.LINE_AA)

    def _draw_trajectories(
        self,
        frame: np.ndarray,
        pose: CameraPose,
        fit_res: TrajectoryFitResult,
        cf_traj: CounterfactualTrajectory,
        t_curr: float,
        t_bounce: float,
        t_impact: float,
    ):
        """Draws actual (red tube) and counterfactual (blue tube) 3D trajectory segments."""
        # Active observed / actual path up to t_curr
        mask_actual = fit_res.timestamps <= t_curr
        if np.sum(mask_actual) >= 2:
            pts_actual_3d = fit_res.trajectory_3d[mask_actual]
            # Split before and after impact
            ts_actual = fit_res.timestamps[mask_actual]
            mask_pre_impact = ts_actual <= t_impact
            
            # Pre-impact solid tube
            if np.sum(mask_pre_impact) >= 2:
                pts_pre = pts_actual_3d[mask_pre_impact]
                pts_2d = pose.project(pts_pre).astype(np.int32)
                # Outer shadow
                cv2.polylines(frame, [pts_2d], isClosed=False, color=(20, 20, 150), thickness=6, lineType=cv2.LINE_AA)
                # Bright red tube
                cv2.polylines(frame, [pts_2d], isClosed=False, color=(30, 30, 240), thickness=4, lineType=cv2.LINE_AA)
                # Inner specular highlight
                cv2.polylines(frame, [pts_2d], isClosed=False, color=(160, 160, 255), thickness=1, lineType=cv2.LINE_AA)

            # Post-impact uncertain projection (rendered as dashed / semi-transparent cone envelope)
            mask_post_impact = ts_actual > t_impact
            if np.sum(mask_post_impact) >= 2:
                pts_post = pts_actual_3d[mask_post_impact]
                pts_post_2d = pose.project(pts_post).astype(np.int32)
                # Draw dashed line
                for k in range(0, len(pts_post_2d) - 1, 2):
                    pt_a = tuple(pts_post_2d[k])
                    pt_b = tuple(pts_post_2d[min(k + 1, len(pts_post_2d) - 1)])
                    cv2.line(frame, pt_a, pt_b, (40, 40, 230), 2, lineType=cv2.LINE_AA)

                # Draw uncertainty cone envelope around post-impact path
                overlay = frame.copy()
                cone_w = np.linspace(3, 14, len(pts_post_2d))
                poly_left = []
                poly_right = []
                for idx_p, pt in enumerate(pts_post_2d):
                    w_px = cone_w[idx_p]
                    poly_left.append([pt[0] - w_px, pt[1]])
                    poly_right.append([pt[0] + w_px, pt[1]])
                cone_pts = np.array(poly_left + poly_right[::-1], dtype=np.int32)
                cv2.fillPoly(overlay, [cone_pts], (40, 40, 230))
                cv2.addWeighted(overlay, 0.25, frame, 0.75, 0, frame)

        # Counterfactual trajectory (blue tube) - rendered after bounce
        if t_curr >= t_bounce:
            mask_cf = (cf_traj.timestamps >= t_bounce) & (cf_traj.timestamps <= t_curr)
            if np.sum(mask_cf) >= 2:
                pts_cf_3d = cf_traj.trajectory_3d[mask_cf]
                pts_cf_2d = pose.project(pts_cf_3d).astype(np.int32)
                # Outer shadow
                cv2.polylines(frame, [pts_cf_2d], isClosed=False, color=(140, 80, 10), thickness=5, lineType=cv2.LINE_AA)
                # Electric blue tube
                cv2.polylines(frame, [pts_cf_2d], isClosed=False, color=(240, 160, 20), thickness=3, lineType=cv2.LINE_AA)
                # Specular core
                cv2.polylines(frame, [pts_cf_2d], isClosed=False, color=(255, 230, 180), thickness=1, lineType=cv2.LINE_AA)

    def _draw_verdict_panel(self, frame: np.ndarray, lbw: LBWDecision, fit_res: TrajectoryFitResult):
        """Draws broadcast-style LBW decision review panel in top-right corner."""
        h, w = frame.shape[:2]
        panel_w = 340
        panel_h = 210
        px = w - panel_w - 25
        py = 35

        overlay = frame.copy()
        cv2.rectangle(overlay, (px, py), (px + panel_w, py + panel_h), (25, 25, 25), -1)
        cv2.rectangle(overlay, (px, py), (px + panel_w, py + panel_h), (200, 200, 200), 2)
        cv2.addWeighted(overlay, 0.85, frame, 0.15, 0, frame)

        # Title bar
        cv2.rectangle(frame, (px, py), (px + panel_w, py + 34), (40, 40, 40), -1)
        cv2.putText(frame, "HAWK-EYE DRS REVIEW", (px + 12, py + 24), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)

        rows = [
            ("PITCHING", lbw.pitching_verdict.value, (0, 200, 0) if lbw.pitching_verdict == PitchingVerdict.IN_LINE else (0, 0, 220)),
            ("IMPACT", lbw.impact_verdict.value, (0, 200, 0) if lbw.impact_verdict == ImpactVerdict.IN_LINE else ((0, 180, 240) if lbw.impact_verdict == ImpactVerdict.UMPIRES_CALL else (0, 0, 220))),
            ("WICKETS", lbw.wickets_verdict.value, (0, 200, 0) if lbw.wickets_verdict == WicketsVerdict.HITTING else ((0, 180, 240) if lbw.wickets_verdict == WicketsVerdict.UMPIRES_CALL else (0, 0, 220))),
        ]

        row_y = py + 68
        for label, val, color in rows:
            cv2.putText(frame, label, (px + 15, row_y), cv2.FONT_HERSHEY_SIMPLEX, 0.50, (200, 200, 200), 1, cv2.LINE_AA)
            # Value badge
            badge_x = px + 140
            cv2.rectangle(frame, (badge_x, row_y - 18), (px + panel_w - 15, row_y + 6), color, -1)
            cv2.putText(frame, val, (badge_x + 8, row_y - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 2, cv2.LINE_AA)
            row_y += 35

        # Final verdict banner
        verdict_color = (0, 180, 0) if "OUT" in lbw.overall_decision and "NOT" not in lbw.overall_decision else (0, 0, 220)
        cv2.rectangle(frame, (px + 10, py + panel_h - 38), (px + panel_w - 10, py + panel_h - 8), verdict_color, -1)
        cv2.putText(frame, lbw.overall_decision, (px + 20, py + panel_h - 17), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 2, cv2.LINE_AA)

    def render_virtual_view(
        self,
        fit_res: TrajectoryFitResult,
        cf_traj: CounterfactualTrajectory,
        lbw: LBWDecision,
        out_path: str | Path,
        fps: float = 50.0,
        num_frames: int = 60,
    ) -> Path:
        """Renders synthetic 3D virtual view from behind the striker's stumps looking towards bowler."""
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        w, h = 1280, 720

        # Synthetic camera placed behind striker's stumps (X = -2.8 m, Y = 0.0 m, Z = 1.05 m)
        # Looking down the pitch toward (X = 12.0, Y = 0.0, Z = 0.6)
        C_synth = np.array([-2.8, 0.0, 1.05], dtype=np.float64)
        target = np.array([12.0, 0.0, 0.6], dtype=np.float64)
        up = np.array([0.0, 0.0, 1.0], dtype=np.float64)

        # Compute camera coordinate frame
        fwd = (target - C_synth) / np.linalg.norm(target - C_synth)
        right = np.cross(fwd, up)
        right /= np.linalg.norm(right)
        cam_up = np.cross(right, fwd)

        # OpenCV camera: X-right, Y-down, Z-forward
        R_synth = np.vstack([right, -cam_up, fwd])
        t_synth = -R_synth @ C_synth.reshape(3, 1)
        f_synth = 950.0
        K_synth = np.array([[f_synth, 0, w / 2.0], [0, f_synth, h / 2.0], [0, 0, 1.0]])
        pose_synth = CameraPose(K=K_synth, R=R_synth, t=t_synth)

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(out_path), fourcc, fps, (w, h))

        # Base background canvas: stadium turf, pitch strip, creases, and stumps
        base_canvas = self._render_synthetic_pitch(w, h, pose_synth)

        total_pts = len(fit_res.trajectory_3d)
        for frame_idx in range(num_frames):
            frame = base_canvas.copy()
            # Fraction of trajectory revealed
            frac = min(1.0, (frame_idx + 1) / (num_frames * 0.75))
            pts_count = max(2, int(frac * total_pts))

            # 1. Trajectory paths
            # Actual (Red tube)
            actual_3d = fit_res.trajectory_3d[:pts_count]
            pts_2d = pose_synth.project(actual_3d).astype(np.int32)
            cv2.polylines(frame, [pts_2d], isClosed=False, color=(20, 20, 180), thickness=6, lineType=cv2.LINE_AA)
            cv2.polylines(frame, [pts_2d], isClosed=False, color=(40, 40, 240), thickness=4, lineType=cv2.LINE_AA)

            # Counterfactual (Blue tube) after bounce
            t_thresh = fit_res.timestamps[pts_count - 1]
            if t_thresh >= fit_res.bounce_time:
                mask_cf = (cf_traj.timestamps >= fit_res.bounce_time) & (cf_traj.timestamps <= t_thresh)
                if np.sum(mask_cf) >= 2:
                    cf_3d = cf_traj.trajectory_3d[mask_cf]
                    cf_2d = pose_synth.project(cf_3d).astype(np.int32)
                    cv2.polylines(frame, [cf_2d], isClosed=False, color=(160, 80, 10), thickness=5, lineType=cv2.LINE_AA)
                    cv2.polylines(frame, [cf_2d], isClosed=False, color=(240, 150, 20), thickness=3, lineType=cv2.LINE_AA)

            # 2. Draw current ball position as 3D shaded sphere
            curr_pos_3d = actual_3d[-1]
            ball_center_2d = pose_synth.project(curr_pos_3d.reshape(1, 3))[0].astype(np.int32)
            # Apparent radius scales with depth
            z_cam = (pose_synth.R @ curr_pos_3d.reshape(3, 1) + pose_synth.t)[2, 0]
            ball_r_px = max(4, int(f_synth * self.cfg.ball.radius / max(z_cam, 0.5)))
            cv2.circle(frame, tuple(ball_center_2d), ball_r_px, (20, 20, 240), -1, lineType=cv2.LINE_AA)
            cv2.circle(frame, (ball_center_2d[0] - ball_r_px // 3, ball_center_2d[1] - ball_r_px // 3), max(1, ball_r_px // 3), (180, 180, 255), -1, lineType=cv2.LINE_AA)

            # 3. Virtual view broadcast telemetry overlay
            cv2.putText(frame, "VIRTUAL STUMP CAM - 3D BALL TRACKING", (30, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
            cv2.putText(frame, f"Speed: {fit_res.speed_release_kmh:.1f} km/h   Seam Turn: {cf_traj.turn_seam_angle_deg:.2f} deg ({cf_traj.turn_seam_deviation_cm:+.1f} cm)", (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1, cv2.LINE_AA)

            writer.write(frame)

        writer.release()
        logger.info(f"Exported virtual view video to {out_path}")
        return out_path

    def _render_synthetic_pitch(self, w: int, h: int, pose: CameraPose) -> np.ndarray:
        """Renders 3D synthetic pitch strip, creases, stumps, and stadium ground."""
        canvas = np.zeros((h, w, 3), dtype=np.uint8)
        # Lush grass background
        canvas[:] = (35, 85, 30)

        # Pitch strip polygon (3.05 m wide, from X = -1.5 to 21.5)
        pitch_corners_3d = np.array([
            [-1.5, -1.525, 0.0],
            [-1.5, 1.525, 0.0],
            [21.5, 1.525, 0.0],
            [21.5, -1.525, 0.0],
        ])
        pts_pitch_2d = pose.project(pitch_corners_3d).astype(np.int32)
        cv2.fillPoly(canvas, [pts_pitch_2d], (140, 180, 205))  # Light tan/clay pitch

        # Blue corridor between stump lines
        w_stump = self.cfg.lbw.stump_half_width
        corridor_3d = np.array([
            [0.0, -w_stump, 0.0],
            [0.0, w_stump, 0.0],
            [20.12, w_stump, 0.0],
            [20.12, -w_stump, 0.0],
        ])
        pts_corr_2d = pose.project(corridor_3d).astype(np.int32)
        overlay = canvas.copy()
        cv2.fillPoly(overlay, [pts_corr_2d], (230, 160, 40))
        cv2.addWeighted(overlay, 0.4, canvas, 0.6, 0, canvas)

        # White crease markings
        # Popping crease (X = 1.22, Y from -1.8 to +1.8)
        pop_crease_3d = np.array([[1.22, -1.8, 0.0], [1.22, 1.8, 0.0]])
        pop_2d = pose.project(pop_crease_3d).astype(np.int32)
        cv2.line(canvas, tuple(pop_2d[0]), tuple(pop_2d[1]), (255, 255, 255), 2, lineType=cv2.LINE_AA)

        # Bowling crease (X = 0, Y from -1.32 to +1.32)
        bowl_crease_3d = np.array([[0.0, -1.32, 0.0], [0.0, 1.32, 0.0]])
        bowl_2d = pose.project(bowl_crease_3d).astype(np.int32)
        cv2.line(canvas, tuple(bowl_2d[0]), tuple(bowl_2d[1]), (255, 255, 255), 2, lineType=cv2.LINE_AA)

        # Return creases (Y = +-1.32, X from -0.5 to 1.22)
        for sign in [-1.0, 1.0]:
            ret_3d = np.array([[-0.5, sign * 1.32, 0.0], [1.22, sign * 1.32, 0.0]])
            ret_2d = pose.project(ret_3d).astype(np.int32)
            cv2.line(canvas, tuple(ret_2d[0]), tuple(ret_2d[1]), (255, 255, 255), 2, lineType=cv2.LINE_AA)

        # Striker stumps (3 wooden posts at X = 0)
        h_stump = self.cfg.pitch.stump_height
        for y_pos in [-w_stump, 0.0, w_stump]:
            base_3d = np.array([[0.0, y_pos, 0.0]])
            top_3d = np.array([[0.0, y_pos, h_stump]])
            p_base = pose.project(base_3d)[0].astype(np.int32)
            p_top = pose.project(top_3d)[0].astype(np.int32)
            cv2.line(canvas, tuple(p_base), tuple(p_top), (220, 240, 255), 4, lineType=cv2.LINE_AA)

        # Bails across stumps
        p_bail_left = pose.project(np.array([[0.0, -w_stump - 0.01, h_stump]]))[0].astype(np.int32)
        p_bail_right = pose.project(np.array([[0.0, w_stump + 0.01, h_stump]]))[0].astype(np.int32)
        cv2.line(canvas, tuple(p_bail_left), tuple(p_bail_right), (200, 230, 255), 3, lineType=cv2.LINE_AA)

        return canvas

    def render_top_down_pitch_map(
        self,
        fit_res: TrajectoryFitResult,
        cf_traj: CounterfactualTrajectory,
        lbw: LBWDecision,
        out_path: str | Path,
    ) -> Path:
        """Renders high-resolution top-down 2D pitch map with trajectory, bounce point, and uncertainty ellipse."""
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        fig, ax = plt.subplots(figsize=(14, 6), dpi=150)
        fig.patch.set_facecolor("#121820")
        ax.set_facecolor("#182230")

        # Pitch dimensions
        pitch_len = self.cfg.pitch.length_between_stumps
        pitch_w = self.cfg.pitch.width
        w_stump = self.cfg.lbw.stump_half_width

        # Pitch strip background
        pitch_rect = Rectangle((-1.0, -pitch_w / 2.0), pitch_len + 2.0, pitch_w, color="#3a4a58", alpha=0.9, zorder=1)
        ax.add_patch(pitch_rect)

        # Blue stump corridor
        corridor_rect = Rectangle((0.0, -w_stump), pitch_len, 2 * w_stump, color="#2171b5", alpha=0.35, zorder=2, label="Stump Corridor")
        ax.add_patch(corridor_rect)

        # Crease markings
        # Striker stumps (X=0)
        ax.plot([0, 0], [-w_stump, w_stump], color="white", lw=4, zorder=3, label="Stumps")
        # Striker popping crease (X=1.22)
        ax.plot([1.22, 1.22], [-1.8, 1.8], color="white", lw=2, ls="-", zorder=3)
        # Striker return creases
        ax.plot([-0.5, 1.22], [1.32, 1.32], color="white", lw=2, zorder=3)
        ax.plot([-0.5, 1.22], [-1.32, -1.32], color="white", lw=2, zorder=3)

        # Bowler stumps (X=20.12)
        ax.plot([pitch_len, pitch_len], [-w_stump, w_stump], color="white", lw=4, zorder=3)
        # Bowler popping crease (X=18.90)
        ax.plot([pitch_len - 1.22, pitch_len - 1.22], [-1.8, 1.8], color="white", lw=2, zorder=3)

        # Trajectories in XY plane
        # Actual delivery path (Red)
        ax.plot(fit_res.trajectory_3d[:, 0], fit_res.trajectory_3d[:, 1], color="#e41a1c", lw=2.5, zorder=4, label="Actual Trajectory")
        # Counterfactual path (Blue)
        ax.plot(cf_traj.full_trajectory_3d[:, 0], cf_traj.full_trajectory_3d[:, 1], color="#377eb8", lw=2.2, ls="--", zorder=4, label="If Ball Had Not Turned/Seamed")

        # Pitching (bounce) point
        pb = fit_res.p_bounce
        ax.scatter([pb[0]], [pb[1]], color="#ffff33", s=90, edgecolors="black", lw=1.5, zorder=5, label=f"Pitched ({pb[0]:.2f}m from stumps)")
        ax.annotate(
            f"PITCHED\n{pb[0]:.2f}m",
            xy=(pb[0], pb[1]),
            xytext=(pb[0] + 0.6, pb[1] + 0.35),
            color="#ffff33",
            fontsize=9,
            weight="bold",
            arrowprops=dict(arrowstyle="->", color="#ffff33", lw=1.5),
            zorder=6,
        )

        # Impact point
        p_imp_idx = np.argmin(np.abs(fit_res.trajectory_3d[:, 0] - self.cfg.pitch.popping_crease_dist))
        p_imp = fit_res.trajectory_3d[p_imp_idx]
        ax.scatter([p_imp[0]], [p_imp[1]], color="#ff7f00", s=70, edgecolors="black", lw=1.2, zorder=5, label="Pad Impact")

        # Uncertainty Ellipse at Stump Plane (X = 0)
        # Lateral variance from stump_plane_cov[0, 0]
        sigma_y = np.sqrt(max(fit_res.stump_plane_cov[0, 0], 1e-4))
        # Draw ellipse representing lateral & longitudinal arrival distribution
        ell = Ellipse(
            xy=(0.0, fit_res.p_stump[1]),
            width=0.40,
            height=2.0 * sigma_y,
            angle=0,
            facecolor="#e41a1c",
            alpha=0.45,
            edgecolor="#ffffff",
            lw=1.5,
            zorder=6,
            label=f"Stump Uncertainty (1σ: {sigma_y*100:.1f}cm)",
        )
        ax.add_patch(ell)

        # Plot formatting
        ax.set_xlim(-2.0, pitch_len + 2.0)
        ax.set_ylim(-2.0, 2.0)
        ax.set_xlabel("Pitch Axis X (metres from striker stumps)", color="white", fontsize=11)
        ax.set_ylabel("Lateral Axis Y (metres, +Off / -Leg)", color="white", fontsize=11)
        ax.tick_params(colors="white")
        ax.grid(True, color="#445566", linestyle=":", alpha=0.6)

        # Title and Info Box
        ax.set_title("HAWK-EYE 2D PITCH MAP & TRAJECTORY ANALYSIS", color="white", fontsize=14, weight="bold", pad=12)

        info_text = (
            f"Release Speed: {fit_res.speed_release_kmh:.1f} km/h\n"
            f"Seam Turn: {cf_traj.turn_seam_angle_deg:.2f}° ({cf_traj.turn_seam_deviation_cm:+.1f} cm)\n"
            f"Pitching: {lbw.pitching_verdict.value}\n"
            f"Impact: {lbw.impact_verdict.value}\n"
            f"Wickets: {lbw.wickets_verdict.value} (Prob: {lbw.prob_hitting*100:.1f}%)\n"
            f"VERDICT: {lbw.overall_decision}"
        )
        ax.text(
            0.02, 0.05, info_text,
            transform=ax.transAxes,
            color="white",
            fontsize=9.5,
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.6", facecolor="#10141a", edgecolor="#556677", alpha=0.9),
            zorder=7,
        )

        ax.legend(loc="upper right", facecolor="#10141a", edgecolor="#556677", labelcolor="white", fontsize=9)
        plt.tight_layout()
        plt.savefig(str(out_path), facecolor=fig.get_facecolor(), edgecolor="none")
        plt.close(fig)

        logger.info(f"Exported pitch map image to {out_path}")
        return out_path

    def export_results_json(
        self,
        fit_res: TrajectoryFitResult,
        cf_traj: CounterfactualTrajectory,
        lbw: LBWDecision,
        events: DeliveryEvents,
        camera_poses: List[CameraPose],
        track_points: List[TrackPoint],
        out_path: str | Path,
        pitching_point: Optional[Any] = None,
        status: str = "SUCCESS",
        failing_stage: Optional[str] = None,
    ) -> Path:
        """Exports complete trajectory parameters, event metrics, covariance, and verdicts to JSON."""
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        mean_calib_err = float(np.mean([p.reprojection_error for p in camera_poses if p.is_valid])) if camera_poses else 0.0
        mean_track_conf = float(np.mean([p.confidence for p in track_points])) if track_points else 0.0

        p_imp_idx = np.argmin(np.abs(fit_res.trajectory_3d[:, 0] - self.cfg.pitch.popping_crease_dist))
        p_impact = fit_res.trajectory_3d[p_imp_idx]

        data = {
            "status": status,
            "failing_stage": failing_stage,
            "overall_verdict": lbw.overall_decision,
            "pitching": {
                "x_m": float(pitching_point.x) if pitching_point is not None else float(fit_res.p_bounce[0]),
                "y_m": float(pitching_point.y) if pitching_point is not None else float(fit_res.p_bounce[1]),
                "dist_from_stumps_m": float(pitching_point.x) if pitching_point is not None else float(fit_res.p_bounce[0]),
                "verdict": lbw.pitching_verdict.value,
                "is_observed": events.bounce_is_observed,
                "subframe_time_s": float(events.bounce_time),
            },
            "impact": {
                "x_m": float(p_impact[0]),
                "y_m": float(p_impact[1]),
                "z_m": float(p_impact[2]),
                "frame": events.impact_frame,
                "time_s": float(events.impact_time),
                "verdict": lbw.impact_verdict.value,
            },
            "wickets": {
                "predicted_y_m": float(fit_res.p_stump[1]),
                "predicted_z_m": float(fit_res.p_stump[2]),
                "verdict": lbw.wickets_verdict.value,
                "probability_hitting": float(lbw.prob_hitting),
                "stump_plane_covariance": fit_res.stump_plane_cov.tolist(),
                "ellipse_1sigma": {
                    "semi_major_m": float(lbw.ellipse.semi_major_m),
                    "semi_minor_m": float(lbw.ellipse.semi_minor_m),
                    "angle_deg": float(lbw.ellipse.angle_deg),
                },
            },
            "delivery_metrics": {
                "speed_release_kmh": float(fit_res.speed_release_kmh),
                "speed_bounce_kmh": float(np.linalg.norm(fit_res.v_bounce_before) * 3.6),
                "swing_accel_ms2": float(fit_res.swing_accel),
                "turn_seam_angle_deg": float(cf_traj.turn_seam_angle_deg),
                "turn_seam_deviation_cm": float(cf_traj.turn_seam_deviation_cm),
                "restitution_e": float(fit_res.restitution_e),
                "friction_x": float(fit_res.friction_x),
            },
            "quality_confidence": {
                "mean_reprojection_error_px": float(fit_res.mean_reprojection_error_px),
                "mean_calibration_error_px": float(mean_calib_err),
                "mean_tracking_confidence": float(mean_track_conf),
                "is_converged": fit_res.is_converged,
            },
        }

        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        logger.info(f"Exported result JSON to {out_path}")
        return out_path
