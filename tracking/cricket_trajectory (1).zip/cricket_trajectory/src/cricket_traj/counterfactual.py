"""Counterfactual 'If ball had not turned/seamed' trajectory generation and deviation analysis."""

from dataclasses import dataclass
import numpy as np
from typing import Optional

from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.fit import TrajectoryFitResult
from cricket_traj.physics import BallPhysics, PhysicsParams


@dataclass
class CounterfactualTrajectory:
    """Counterfactual delivery path assuming zero post-bounce spin/seam lateral kick."""
    timestamps: np.ndarray             # (M,)
    trajectory_3d: np.ndarray          # (M, 3) 3D path from bounce to stump plane
    full_trajectory_3d: np.ndarray     # (Total, 3) complete path from release through counterfactual stump plane
    full_timestamps: np.ndarray        # (Total,)
    p_stump: np.ndarray                # (3,) Position at X = 0 without turn/seam: [0, Y_cf, Z_cf]
    turn_seam_deviation_cm: float      # Net lateral deviation at stump plane in centimetres
    turn_seam_angle_deg: float         # Horizontal deflection angle at bounce in degrees


class CounterfactualGenerator:
    """Computes counterfactual trajectory by eliminating post-bounce spin/seam deflection."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG
        self.physics = BallPhysics(self.cfg)

    def generate(self, fit_res: TrajectoryFitResult) -> CounterfactualTrajectory:
        # Pre-bounce path is identical
        tb = fit_res.bounce_time
        p_bounce = fit_res.p_bounce.copy()
        v_before = fit_res.v_bounce_before.copy()

        # Counterfactual post-bounce: seam kick = 0, symmetric lateral restitution/friction
        params_cf = PhysicsParams(
            k_drag=fit_res.k_drag,
            swing_accel=fit_res.swing_accel,
            restitution_e=fit_res.restitution_e,
            friction_x=fit_res.friction_x,
            friction_y=fit_res.friction_x,  # Symmetric friction
            seam_lateral_kick=0.0,          # Zero turn/seam kick
        )

        # Counterfactual velocity after bounce: no lateral impulse
        v_cf_after = np.array([
            (1.0 - fit_res.friction_x) * v_before[0],
            (1.0 - fit_res.friction_x) * v_before[1],
            -fit_res.restitution_e * v_before[2],
        ], dtype=np.float64)

        # Integrate counterfactual path to striker stump plane X = 0
        t_stump_cf, p_stump_cf, v_stump_cf, ts_cf_post, pos_cf_post = self.physics.integrate_to_stump_plane(
            p_start=p_bounce,
            v_start=v_cf_after,
            t_start=tb,
            params=params_cf,
            target_x=0.0,
            dt=0.002,
        )

        # Build full counterfactual path (sharing pre-bounce segment)
        pre_mask = fit_res.timestamps <= tb
        full_ts = np.concatenate([fit_res.timestamps[pre_mask], ts_cf_post[1:]])
        full_pos = np.concatenate([fit_res.trajectory_3d[pre_mask], pos_cf_post[1:]])

        # Lateral deviation at stump plane (in cm)
        # Difference in Y between actual ball center and counterfactual ball center
        dev_y_m = fit_res.p_stump[1] - p_stump_cf[1]
        dev_y_cm = float(dev_y_m * 100.0)

        # Horizontal deflection angle at bounce
        # Angle of velocity vector in XY plane: atan2(Vy, -Vx)
        # Note -Vx because Vx is negative (travelling towards X=0)
        ang_actual = np.arctan2(fit_res.v_bounce_after[1], -fit_res.v_bounce_after[0])
        ang_cf = np.arctan2(v_cf_after[1], -v_cf_after[0])
        dev_ang_deg = float(np.degrees(ang_actual - ang_cf))

        return CounterfactualTrajectory(
            timestamps=ts_cf_post,
            trajectory_3d=pos_cf_post,
            full_trajectory_3d=full_pos,
            full_timestamps=full_ts,
            p_stump=p_stump_cf,
            turn_seam_deviation_cm=dev_y_cm,
            turn_seam_angle_deg=dev_ang_deg,
        )
