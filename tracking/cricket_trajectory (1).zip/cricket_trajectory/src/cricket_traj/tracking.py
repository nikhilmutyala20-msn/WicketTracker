"""Multi-candidate ball tracking using 3D corridor gating, Viterbi dynamic programming, and Kalman/RTS smoothing."""

from dataclasses import dataclass
import logging
from typing import List, Optional, Tuple
import numpy as np

from cricket_traj.calibration import CameraPose
from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.interfaces import BallCandidate

logger = logging.getLogger(__name__)


@dataclass
class TrackPoint:
    """A smoothed or observed trajectory point in image coordinates."""
    frame_idx: int
    timestamp: float
    x: float
    y: float
    confidence: float
    is_observed: bool
    ray_origin: Optional[np.ndarray] = None
    ray_direction: Optional[np.ndarray] = None
    raw_x: Optional[float] = None
    raw_y: Optional[float] = None


class BallTracker:
    """Selects optimal ball trajectory from multiple candidate detections using Viterbi DP and RTS smoothing."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG

    def track(
        self,
        candidates_per_frame: List[List[BallCandidate]],
        camera_poses: List[CameraPose],
        timestamps: np.ndarray,
        image_shape: Tuple[int, int],
    ) -> List[TrackPoint]:
        num_frames = len(candidates_per_frame)
        if num_frames == 0:
            return []

        h, w = image_shape
        dt_default = 1.0 / self.cfg.camera.default_fps

        # 1. Gate candidates by 3D corridor above pitch
        gated_candidates: List[List[BallCandidate]] = []
        for i in range(num_frames):
            pose = camera_poses[i] if i < len(camera_poses) else None
            cands = candidates_per_frame[i]
            valid_cands: List[BallCandidate] = []
            for c in cands:
                if self._passes_3d_corridor_gate(c, pose, (h, w)):
                    valid_cands.append(c)
            # If all candidates gated out, keep highest confidence one as fallback
            if not valid_cands and cands:
                valid_cands.append(max(cands, key=lambda x: x.confidence))
            gated_candidates.append(valid_cands[: self.cfg.tracking.top_k_candidates])

        # 2. Viterbi Dynamic Programming over candidate graph
        track_2d, is_observed = self._viterbi_selection(gated_candidates, timestamps, (h, w))

        # 3. Kalman / RTS smoothing to fill gaps and smooth jitter
        smoothed_points = self._rts_smooth_track(
            track_2d=track_2d,
            is_observed=is_observed,
            timestamps=timestamps,
            camera_poses=camera_poses,
        )

        return smoothed_points

    def _passes_3d_corridor_gate(
        self,
        cand: BallCandidate,
        pose: Optional[CameraPose],
        image_shape: Tuple[int, int],
    ) -> bool:
        """Checks if a 2D candidate ray passes through the 3D cricket pitch corridor."""
        h, w = image_shape
        if not (0.10 * w <= cand.x <= 0.90 * w and 0.08 * h <= cand.y <= 0.98 * h):
            return False

        if pose is None or not pose.is_valid:
            return True

        C, d = pose.ray(cand.x, cand.y)
        if abs(d[0]) > 1e-4:
            for x_eval in [18.0, 14.0, 10.0, 6.0, 2.0]:
                lam = (x_eval - C[0]) / d[0]
                if lam > 0.1:
                    y = C[1] + lam * d[1]
                    z = C[2] + lam * d[2]
                    if abs(y) <= 3.5 and -0.2 <= z <= 4.5:
                        return True
        elif abs(d[2]) > 1e-4:
            lam = -C[2] / d[2]
            if lam > 0.1:
                x = C[0] + lam * d[0]
                y = C[1] + lam * d[1]
                if -2.0 <= x <= 23.0 and abs(y) <= 3.5:
                    return True

        return 0.20 * w <= cand.x <= 0.80 * w and 0.12 * h <= cand.y <= 0.92 * h
    def _viterbi_selection(
        self,
        candidates_list: List[List[BallCandidate]],
        timestamps: np.ndarray,
        image_shape: Tuple[int, int],
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Selects consistent trajectory using Dynamic Programming (Viterbi)."""
        N = len(candidates_list)
        h, w = image_shape

        # For each frame t, states are candidate indices [0 .. len(candidates_list[t])-1], plus a dummy MISSED state
        # State representation: list of (x, y, conf)
        nodes: List[List[Tuple[float, float, float, bool]]] = []
        for cands in candidates_list:
            frame_nodes: List[Tuple[float, float, float, bool]] = []
            for c in cands:
                frame_nodes.append((c.x, c.y, c.confidence, True))
            # Dummy missed state
            frame_nodes.append((w / 2.0, h / 2.0, 0.01, False))
            nodes.append(frame_nodes)

        # DP tables: cost[t][state], backpointer[t][state]
        V: List[np.ndarray] = []
        BP: List[np.ndarray] = []

        # Initialize t = 0
        V0 = np.zeros(len(nodes[0]))
        for j, (x, y, conf, obs) in enumerate(nodes[0]):
            V0[j] = -np.log(max(conf, 1e-4)) if obs else self.cfg.tracking.viterbi_miss_penalty
        V.append(V0)
        BP.append(np.zeros(len(nodes[0]), dtype=int))

        # Forward DP
        max_px_speed = w * 0.4  # Max pixels per second displacement
        for t in range(1, N):
            num_prev = len(nodes[t - 1])
            num_curr = len(nodes[t])
            Vt = np.full(num_curr, np.inf)
            BPt = np.zeros(num_curr, dtype=int)
            dt = max(float(timestamps[t] - timestamps[t - 1]), 1e-3)

            for j, (x_curr, y_curr, conf_curr, obs_curr) in enumerate(nodes[t]):
                emission_cost = -np.log(max(conf_curr, 1e-4)) if obs_curr else self.cfg.tracking.viterbi_miss_penalty

                for i, (x_prev, y_prev, conf_prev, obs_prev) in enumerate(nodes[t - 1]):
                    # Transition cost based on distance and acceleration
                    dist = np.hypot(x_curr - x_prev, y_curr - y_prev)
                    speed = dist / dt

                    if obs_curr and obs_prev and speed > max_px_speed * 1.5:
                        trans_cost = 50.0 + speed * 0.1
                    else:
                        trans_cost = self.cfg.tracking.viterbi_dist_weight * (dist / 100.0)

                    total_cost = V[t - 1][i] + trans_cost + emission_cost
                    if total_cost < Vt[j]:
                        Vt[j] = total_cost
                        BPt[j] = i

            V.append(Vt)
            BP.append(BPt)

        # Backtrack
        best_state = int(np.argmin(V[-1]))
        selected_states = [best_state]
        for t in range(N - 1, 0, -1):
            best_state = int(BP[t][best_state])
            selected_states.append(best_state)
        selected_states.reverse()

        track_2d = np.zeros((N, 2), dtype=np.float64)
        is_observed = np.zeros(N, dtype=bool)

        for t in range(N):
            state_idx = selected_states[t]
            x, y, conf, obs = nodes[t][state_idx]
            track_2d[t] = [x, y]
            is_observed[t] = obs

        return track_2d, is_observed

    def _rts_smooth_track(
        self,
        track_2d: np.ndarray,
        is_observed: np.ndarray,
        timestamps: np.ndarray,
        camera_poses: List[CameraPose],
    ) -> List[TrackPoint]:
        """Kalman filter & RTS smoother for constant-acceleration / constant-velocity 2D track."""
        N = len(track_2d)
        if N == 0:
            return []

        # If no observations at all, fill with center
        if not np.any(is_observed):
            is_observed[0] = True

        # Interpolate initial guess for unobserved points
        obs_idx = np.where(is_observed)[0]
        t_all = np.arange(N)
        track_interp_x = np.interp(t_all, obs_idx, track_2d[obs_idx, 0])
        track_interp_y = np.interp(t_all, obs_idx, track_2d[obs_idx, 1])

        # State: [x, y, vx, vy, ax, ay]
        dim = 6
        x_filt = np.zeros((N, dim))
        P_filt = np.zeros((N, dim, dim))
        x_pred = np.zeros((N, dim))
        P_pred = np.zeros((N, dim, dim))

        dt = 1.0 / self.cfg.camera.default_fps
        F = np.eye(dim)
        F[0, 2] = dt
        F[1, 3] = dt
        F[0, 4] = 0.5 * dt * dt
        F[1, 5] = 0.5 * dt * dt
        F[2, 4] = dt
        F[3, 5] = dt

        H_mat = np.zeros((2, dim))
        H_mat[0, 0] = 1.0
        H_mat[1, 1] = 1.0

        Q = np.diag([1.0, 1.0, 10.0, 10.0, 50.0, 50.0])
        R_obs = np.diag([4.0, 4.0])
        R_miss = np.diag([1000.0, 1000.0])

        x = np.array([track_interp_x[0], track_interp_y[0], 0.0, 0.0, 0.0, 0.0])
        P = np.eye(dim) * 20.0

        for k in range(N):
            if k == 0:
                x_pred[k] = x
                P_pred[k] = P
            else:
                x_pred[k] = F @ x_filt[k - 1]
                P_pred[k] = F @ P_filt[k - 1] @ F.T + Q

            z = track_2d[k]
            R_k = R_obs if is_observed[k] else R_miss
            y_meas = z - H_mat @ x_pred[k]
            S = H_mat @ P_pred[k] @ H_mat.T + R_k
            K_gain = P_pred[k] @ H_mat.T @ np.linalg.inv(S)
            x_filt[k] = x_pred[k] + K_gain @ y_meas
            P_filt[k] = (np.eye(dim) - K_gain @ H_mat) @ P_pred[k]

        # RTS Backward Pass
        x_smooth = np.zeros((N, dim))
        x_smooth[-1] = x_filt[-1]
        for k in range(N - 2, -1, -1):
            C = P_filt[k] @ F.T @ np.linalg.inv(P_pred[k + 1])
            x_smooth[k] = x_filt[k] + C @ (x_smooth[k + 1] - x_pred[k + 1])

        results: List[TrackPoint] = []
        for i in range(N):
            px = float(x_smooth[i, 0])
            py = float(x_smooth[i, 1])
            pose = camera_poses[i] if i < len(camera_poses) else None
            ray_org, ray_dir = pose.ray(px, py) if pose and pose.is_valid else (None, None)

            results.append(
                TrackPoint(
                    frame_idx=i,
                    timestamp=float(timestamps[i]),
                    x=px,
                    y=py,
                    confidence=0.95 if is_observed[i] else 0.40,
                    is_observed=bool(is_observed[i]),
                    ray_origin=ray_org,
                    ray_direction=ray_dir,
                    raw_x=float(track_2d[i, 0]) if is_observed[i] else None,
                    raw_y=float(track_2d[i, 1]) if is_observed[i] else None,
                )
            )

        return results
