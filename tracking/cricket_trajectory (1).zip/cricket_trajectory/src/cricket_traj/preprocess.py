"""Video preprocessing: deinterlacing, duplicate frame detection, timestamps, overlay cropping, and shot cut detection."""

from dataclasses import dataclass, field
import logging
from pathlib import Path
from typing import List, Optional, Tuple
import cv2
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class PreprocessedVideo:
    """Preprocessed video container with metadata and frame attributes."""
    frames: List[np.ndarray]
    timestamps: np.ndarray             # Per-frame timestamps in seconds
    fps: float
    width: int
    height: int
    is_duplicate: List[bool]           # True if frame is a duplicate/freeze frame
    overlay_mask: np.ndarray           # Binary mask (H, W), 1 = valid image, 0 = overlay
    cut_indices: List[int] = field(default_factory=list) # Frame indices where a camera cut was detected


class VideoPreprocessor:
    """Handles deinterlacing, duplicate frame detection, timestamp generation, overlay cropping, and shot cut detection."""

    def __init__(
        self,
        deinterlace_bob: bool = False,
        duplicate_mad_thresh: float = 1.2,
        overlay_bottom_ratio: float = 0.12,  # Typical score ticker height
        overlay_top_ratio: float = 0.05,     # Broadcaster logo margin
        cut_diff_thresh: float = 40.0,
    ):
        self.deinterlace_bob = deinterlace_bob
        self.duplicate_mad_thresh = duplicate_mad_thresh
        self.overlay_bottom_ratio = overlay_bottom_ratio
        self.overlay_top_ratio = overlay_top_ratio
        self.cut_diff_thresh = cut_diff_thresh

    def process(
        self,
        video_path: str | Path,
        fps_override: Optional[float] = None,
        max_frames: Optional[int] = None,
    ) -> PreprocessedVideo:
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            raise FileNotFoundError(f"Could not open video file: {video_path}")

        orig_fps = cap.get(cv2.CAP_PROP_FPS)
        fps = float(fps_override) if fps_override and fps_override > 0 else (orig_fps if orig_fps > 0 else 50.0)

        raw_frames: List[np.ndarray] = []
        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                break
            if self.deinterlace_bob:
                frame = self.bob_deinterlace(frame)
            raw_frames.append(frame)
            if max_frames and len(raw_frames) >= max_frames:
                break
        cap.release()

        if not raw_frames:
            raise ValueError(f"No frames could be read from video {video_path}")

        h, w = raw_frames[0].shape[:2]
        num_frames = len(raw_frames)
        timestamps = np.arange(num_frames, dtype=np.float64) / fps

        # Compute static overlay mask (excluding bottom score bar and top margin)
        overlay_mask = np.ones((h, w), dtype=np.uint8)
        bottom_h = int(h * self.overlay_bottom_ratio)
        top_h = int(h * self.overlay_top_ratio)
        if bottom_h > 0:
            overlay_mask[h - bottom_h :, :] = 0
        if top_h > 0:
            overlay_mask[:top_h, :] = 0

        # Duplicate frame detection and cut detection
        is_duplicate: List[bool] = [False] * num_frames
        cut_indices: List[int] = []

        prev_gray: Optional[np.ndarray] = None
        for i, frame in enumerate(raw_frames):
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Mask out overlay
            masked_gray = gray * overlay_mask
            if prev_gray is not None:
                # Mean Absolute Difference on active pixels
                active_count = np.count_nonzero(overlay_mask)
                diff = np.abs(masked_gray.astype(np.float32) - prev_gray.astype(np.float32))
                mad = float(np.sum(diff) / max(active_count, 1))

                if mad < self.duplicate_mad_thresh:
                    is_duplicate[i] = True
                elif mad > self.cut_diff_thresh:
                    cut_indices.append(i)
                    logger.warning(f"Shot cut detected at frame {i} (MAD={mad:.1f})")

            prev_gray = masked_gray

        return PreprocessedVideo(
            frames=raw_frames,
            timestamps=timestamps,
            fps=fps,
            width=w,
            height=h,
            is_duplicate=is_duplicate,
            overlay_mask=overlay_mask,
            cut_indices=cut_indices,
        )

    @staticmethod
    def bob_deinterlace(frame: np.ndarray) -> np.ndarray:
        """Applies single-frame bob deinterlacing: interpolates alternate scanlines."""
        out = frame.copy()
        # Even scanlines interpolated from adjacent odd lines
        out[1:-1:2] = (out[0:-2:2].astype(np.uint16) + out[2::2].astype(np.uint16)) // 2
        return out
