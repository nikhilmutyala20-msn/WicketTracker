"""Hawk-Eye style LBW rules engine, Gaussian probability mass calculation, and verdict determination."""

from dataclasses import dataclass, field
from enum import Enum
import logging
from typing import Dict, List, Optional, Tuple
import numpy as np
from scipy.integrate import dblquad

from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.fit import TrajectoryFitResult

logger = logging.getLogger(__name__)


class PitchingVerdict(str, Enum):
    IN_LINE = "IN LINE"
    OUTSIDE_OFF = "OUTSIDE OFF"
    OUTSIDE_LEG = "OUTSIDE LEG"


class ImpactVerdict(str, Enum):
    IN_LINE = "IN LINE"
    UMPIRES_CALL = "UMPIRE'S CALL"
    OUTSIDE_OFF = "OUTSIDE OFF"
    OUTSIDE_LEG = "OUTSIDE LEG"


class WicketsVerdict(str, Enum):
    HITTING = "HITTING"
    UMPIRES_CALL = "UMPIRE'S CALL"
    MISSING = "MISSING"


@dataclass
class UncertaintyEllipse:
    """Parameters of 2D uncertainty ellipse at stump plane (Y, Z)."""
    center_y: float
    center_z: float
    semi_major_m: float
    semi_minor_m: float
    angle_deg: float                   # Rotation angle in degrees


@dataclass
class LBWDecision:
    """Comprehensive LBW decision outcome with individual criteria and overall verdict."""
    pitching_verdict: PitchingVerdict
    impact_verdict: ImpactVerdict
    wickets_verdict: WicketsVerdict
    overall_decision: str              # "OUT", "NOT OUT", or "UMPIRE'S CALL"
    prob_hitting: float                # Probability mass inside stumps rectangle
    pitching_y: float
    impact_y: float
    stump_y: float
    stump_z: float
    ellipse: UncertaintyEllipse
    stump_plane_cov: np.ndarray


class LBWClassifier:
    """Evaluates Hawk-Eye LBW rules against 3D trajectory and uncertainty predictions."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG

    def evaluate(
        self,
        fit_res: TrajectoryFitResult,
        impact_point: Optional[np.ndarray] = None,
        shot_offered: bool = True,
    ) -> LBWDecision:
        w_stump = self.cfg.lbw.stump_half_width   # 0.1143 m
        h_stump = self.cfg.pitch.stump_height     # 0.711 m
        r_ball = self.cfg.ball.radius             # 0.036 m
        handedness = self.cfg.lbw.handedness.lower()

        # 1. Pitching Verdict
        y_bounce = float(fit_res.p_bounce[1])
        if abs(y_bounce) <= w_stump:
            pitching_v = PitchingVerdict.IN_LINE
        else:
            if handedness == "right":
                pitching_v = PitchingVerdict.OUTSIDE_OFF if y_bounce > w_stump else PitchingVerdict.OUTSIDE_LEG
            else:
                pitching_v = PitchingVerdict.OUTSIDE_LEG if y_bounce > w_stump else PitchingVerdict.OUTSIDE_OFF

        # 2. Impact Verdict
        # If impact_point not explicitly passed, locate point where X is closest to popping crease (X ~ 1.2 m)
        if impact_point is None:
            # Approximate impact at popping crease or 1.2 m
            idx_near = np.argmin(np.abs(fit_res.trajectory_3d[:, 0] - self.cfg.pitch.popping_crease_dist))
            impact_point = fit_res.trajectory_3d[idx_near]

        y_impact = float(impact_point[1])
        x_impact = float(impact_point[0])

        if x_impact < self.cfg.lbw.impact_forward_min_x:
            # Impact behind stumps is not LBW
            impact_v = ImpactVerdict.OUTSIDE_OFF
        elif abs(y_impact) <= w_stump:
            impact_v = ImpactVerdict.IN_LINE
        elif abs(y_impact) <= w_stump + r_ball:
            impact_v = ImpactVerdict.UMPIRES_CALL
        else:
            if handedness == "right":
                impact_v = ImpactVerdict.OUTSIDE_OFF if y_impact > w_stump else ImpactVerdict.OUTSIDE_LEG
            else:
                impact_v = ImpactVerdict.OUTSIDE_LEG if y_impact > w_stump else ImpactVerdict.OUTSIDE_OFF

        # 3. Wickets Verdict at X = 0
        y_stump = float(fit_res.p_stump[1])
        z_stump = float(fit_res.p_stump[2])
        cov_yz = fit_res.stump_plane_cov

        # Compute probability mass of Gaussian inside outer stump hitting region
        # Outer boundary: |y| <= w_stump + r_ball, 0 <= z <= h_stump + r_ball
        prob_hit = self._compute_probability_mass(
            mu=[y_stump, z_stump],
            cov=cov_yz,
            y_bounds=(-w_stump - r_ball, w_stump + r_ball),
            z_bounds=(0.0, h_stump + r_ball),
        )

        # Core stump boundaries
        in_y_core = abs(y_stump) <= w_stump
        in_z_core = 0.0 <= z_stump <= h_stump

        # Outer clipping zone (within 1 ball radius of stump edges)
        in_y_outer = abs(y_stump) <= w_stump + r_ball
        in_z_outer = 0.0 <= z_stump <= h_stump + r_ball

        if in_y_core and in_z_core:
            # Ball center hits stumps directly
            wickets_v = WicketsVerdict.HITTING
        elif in_y_outer and in_z_outer:
            # Ball clips stumps or bails (less than 50% of ball)
            wickets_v = WicketsVerdict.UMPIRES_CALL
        else:
            wickets_v = WicketsVerdict.MISSING

        # Compute Uncertainty Ellipse
        ellipse = self._compute_ellipse(y_stump, z_stump, cov_yz)

        # Overall LBW Decision
        # Pitching outside leg is ALWAYS NOT OUT
        if pitching_v == PitchingVerdict.OUTSIDE_LEG:
            overall = "NOT OUT (Pitched Outside Leg)"
        elif impact_v in (ImpactVerdict.OUTSIDE_OFF, ImpactVerdict.OUTSIDE_LEG) and shot_offered:
            overall = "NOT OUT (Impact Outside)"
        elif wickets_v == WicketsVerdict.MISSING:
            overall = "NOT OUT (Wickets Missing)"
        elif impact_v == ImpactVerdict.UMPIRES_CALL or wickets_v == WicketsVerdict.UMPIRES_CALL:
            overall = "UMPIRE'S CALL"
        else:
            overall = "OUT (LBW)"

        return LBWDecision(
            pitching_verdict=pitching_v,
            impact_verdict=impact_v,
            wickets_verdict=wickets_v,
            overall_decision=overall,
            prob_hitting=prob_hit,
            pitching_y=y_bounce,
            impact_y=y_impact,
            stump_y=y_stump,
            stump_z=z_stump,
            ellipse=ellipse,
            stump_plane_cov=cov_yz,
        )

    def _compute_probability_mass(
        self,
        mu: List[float],
        cov: np.ndarray,
        y_bounds: Tuple[float, float],
        z_bounds: Tuple[float, float],
    ) -> float:
        """Computes integral of 2D Gaussian over rectangular region [y1, y2] x [z1, z2]."""
        y_min, y_max = y_bounds
        z_min, z_max = z_bounds
        cov_inv = np.linalg.pinv(cov)
        det_cov = max(np.linalg.det(cov), 1e-10)
        norm_factor = 1.0 / (2.0 * np.pi * np.sqrt(det_cov))

        # Vectorized 2D grid numerical integration
        ny, nz = 50, 50
        y_grid = np.linspace(y_min, y_max, ny)
        z_grid = np.linspace(z_min, z_max, nz)
        dy = (y_max - y_min) / (ny - 1)
        dz = (z_max - z_min) / (nz - 1)

        Y, Z = np.meshgrid(y_grid, z_grid)
        dy_pts = Y - mu[0]
        dz_pts = Z - mu[1]

        # Mahalanobis distance squared
        maha = cov_inv[0, 0] * dy_pts**2 + 2.0 * cov_inv[0, 1] * dy_pts * dz_pts + cov_inv[1, 1] * dz_pts**2
        pdf = norm_factor * np.exp(-0.5 * maha)
        prob_mass = float(np.sum(pdf) * dy * dz)
        return float(np.clip(prob_mass, 0.0, 1.0))

    def _compute_ellipse(self, cy: float, cz: float, cov: np.ndarray) -> UncertaintyEllipse:
        """Computes 1-sigma semi-major, semi-minor, and orientation angle of 2D covariance."""
        eigvals, eigvecs = np.linalg.eigh(cov)
        order = eigvals.argsort()[::-1]
        eigvals = eigvals[order]
        eigvecs = eigvecs[:, order]

        # 1-sigma radii
        a = float(np.sqrt(max(eigvals[0], 1e-6)))
        b = float(np.sqrt(max(eigvals[1], 1e-6)))
        angle_rad = np.arctan2(eigvecs[1, 0], eigvecs[0, 0])
        angle_deg = float(np.degrees(angle_rad))

        return UncertaintyEllipse(
            center_y=cy,
            center_z=cz,
            semi_major_m=a,
            semi_minor_m=b,
            angle_deg=angle_deg,
        )
