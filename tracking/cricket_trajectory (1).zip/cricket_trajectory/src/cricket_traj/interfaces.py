"""Abstract interfaces and data structures for ball and pitch detection components."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np


@dataclass
class BallCandidate:
    """A detected ball candidate in image coordinates (pixels)."""
    x: float
    y: float
    confidence: float
    radius: Optional[float] = None
    bbox: Optional[Tuple[float, float, float, float]] = None  # (x_min, y_min, x_max, y_max)

    def as_array(self) -> np.ndarray:
        return np.array([self.x, self.y], dtype=np.float64)


@dataclass
class BallDetectionResult:
    """Ball detections for a single video frame."""
    frame_idx: int
    candidates: List[BallCandidate] = field(default_factory=list)
    timestamp: float = 0.0


@dataclass
class PitchLandmarks:
    """Detected 2D landmarks on the cricket pitch and their 3D correspondence definitions.
    
    Landmark names follow the pitch coordinate system:
      - striker_stump_base: (0.0, 0.0, 0.0)
      - striker_stump_top: (0.0, 0.0, 0.711)
      - striker_off_stump_base: (0.0, 0.1143, 0.0)
      - striker_leg_stump_base: (0.0, -0.1143, 0.0)
      - striker_popping_center: (1.22, 0.0, 0.0)
      - striker_popping_return_off: (1.22, 1.32, 0.0)
      - striker_popping_return_leg: (1.22, -1.32, 0.0)
      - striker_bowling_return_off: (0.0, 1.32, 0.0)
      - striker_bowling_return_leg: (0.0, -1.32, 0.0)
      - bowler_stump_base: (20.12, 0.0, 0.0)
      - bowler_stump_top: (20.12, 0.0, 0.711)
      - bowler_popping_center: (18.90, 0.0, 0.0)
    """
    points_2d: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    pitch_polygon: Optional[np.ndarray] = None  # (N, 2) boundary points in image
    pitch_mask: Optional[np.ndarray] = None     # (H, W) uint8 or bool mask
    confidence: float = 1.0

    @staticmethod
    def get_canonical_3d_coordinates() -> Dict[str, Tuple[float, float, float]]:
        """Returns standard 3D pitch coordinates (in metres) for landmark keys."""
        return {
            "striker_stump_base": (0.0, 0.0, 0.0),
            "striker_stump_top": (0.0, 0.0, 0.711),
            "striker_off_stump_base": (0.0, 0.1143, 0.0),
            "striker_leg_stump_base": (0.0, -0.1143, 0.0),
            "striker_popping_center": (1.22, 0.0, 0.0),
            "striker_popping_return_off": (1.22, 1.32, 0.0),
            "striker_popping_return_leg": (1.22, -1.32, 0.0),
            "striker_bowling_return_off": (0.0, 1.32, 0.0),
            "striker_bowling_return_leg": (0.0, -1.32, 0.0),
            "bowler_stump_base": (20.12, 0.0, 0.0),
            "bowler_stump_top": (20.12, 0.0, 0.711),
            "bowler_popping_center": (18.90, 0.0, 0.0),
            "striker_pitch_corner_off": (0.0, 1.525, 0.0),
            "striker_pitch_corner_leg": (0.0, -1.525, 0.0),
            "bowler_pitch_corner_off": (20.12, 1.525, 0.0),
            "bowler_pitch_corner_leg": (20.12, -1.525, 0.0),
        }

    def get_correspondences(self) -> Tuple[np.ndarray, np.ndarray]:
        """Returns paired (points_3d, points_2d) numpy arrays for visible landmarks."""
        canon = self.get_canonical_3d_coordinates()
        pts_3d = []
        pts_2d = []
        for name, p2 in self.points_2d.items():
            if name in canon and p2 is not None:
                pts_3d.append(canon[name])
                pts_2d.append(p2)
        if not pts_3d:
            return np.zeros((0, 3), dtype=np.float64), np.zeros((0, 2), dtype=np.float64)
        return np.array(pts_3d, dtype=np.float64), np.array(pts_2d, dtype=np.float64)


class BallDetector(ABC):
    """Abstract interface for cricket ball detection across frames."""

    @abstractmethod
    def detect(self, frames: List[np.ndarray]) -> List[List[BallCandidate]]:
        """Detect top-K ball candidates for a sequence of BGR video frames.
        
        Args:
            frames: List of (H, W, 3) BGR images.
            
        Returns:
            List of lists of BallCandidate, one sub-list per frame.
        """
        pass


class PitchDetector(ABC):
    """Abstract interface for cricket pitch landmark and crease detection."""

    @abstractmethod
    def detect(self, frame: np.ndarray) -> PitchLandmarks:
        """Detect pitch landmarks, creases, and stumps for a single BGR frame.
        
        Args:
            frame: (H, W, 3) BGR image.
            
        Returns:
            PitchLandmarks instance.
        """
        pass
