"""Joint nonlinear least-squares trajectory fitting over 3D physics parameters with Huber loss and covariance propagation."""

from dataclasses import dataclass, field
import logging
from typing import Any, List, Optional, Tuple
import numpy as np
from scipy.optimize import least_squares

from cricket_traj.calibration import CameraPose
from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.events import DeliveryEvents
from cricket_traj.physics import BallPhysics, PhysicsParams
from cricket_traj.tracking import TrackPoint

logger = logging.getLogger(__name__)


@dataclass
class TrajectoryFitResult:
    """Fitted delivery trajectory parameters, state vectors, and uncertainty at the stump plane."""
    # Fitted parameters
    p_release: np.ndarray              # (3,) 3D release position (m)
    v_release: np.ndarray              # (3,) 3D release velocity (m/s)
    speed_release_kmh: float
    bounce_time: float                 # Time of bounce (s)
    p_bounce: np.ndarray               # (3,) 3D bounce position (m)
    v_bounce_before: np.ndarray        # (3,) 3D velocity before bounce (m/s)
    v_bounce_after: np.ndarray         # (3,) 3D velocity after bounce (m/s)
    k_drag: float
    swing_accel: float                 # Lateral swing acceleration (m/s^2)
    restitution_e: float
    friction_x: float
    seam_lateral_kick: float           # Imparted lateral velocity (m/s)
    
    # Stump plane arrival (X = 0)
    t_stump: float
    p_stump: np.ndarray                # (3,) Position at X = 0: [0.0, Y_stump, Z_stump]
    v_stump: np.ndarray                # (3,) Velocity at X = 0
    stump_plane_cov: np.ndarray        # (2, 2) covariance matrix for (Y_stump, Z_stump)

    # Dense 3D trajectory polyline for rendering
    timestamps: np.ndarray             # (M,)
    trajectory_3d: np.ndarray          # (M, 3) 3D path from release to stump plane
    
    # Quality metrics
    param_covariance: np.ndarray       # Full parameter covariance matrix
    mean_reprojection_error_px: float
    is_converged: bool = True


class TrajectoryFitter:
    """Fits free-flight and post-bounce cricket ball trajectory jointly using nonlinear least squares."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG
        self.physics = BallPhysics(self.cfg)

    def fit(
        self,
        track: List[TrackPoint],
        camera_poses: List[CameraPose],
        events: DeliveryEvents,
        speed_gun_kmh: Optional[float] = None,
        pitching_point: Optional[Any] = None,
    ) -> TrajectoryFitResult:
        """Jointly fits trajectory parameters using observed pixel tracks and camera poses."""
        N = len(track)
        r_ball = self.cfg.ball.radius

        # Filter points between release and impact
        fit_indices = [
            i for i in range(events.release_frame, min(events.impact_frame + 1, N))
            if track[i].is_observed and camera_poses[i].is_valid
        ]

        if len(fit_indices) < 5:
            logger.warning("Fewer than 5 observed track points; using fallback initialization.")
            fit_indices = list(range(events.release_frame, min(events.impact_frame + 1, N)))

        t_rel = events.release_time
        t_b_init = events.bounce_time
        dt_pre = max(t_b_init - t_rel, 0.15)

        # Initial parameter estimates
        # Striker stumps at X=0, bowler at X=20.12. Ball travels from X ~ 20.0 to X ~ 0.0.
        speed_init_ms = (speed_gun_kmh / 3.6) if speed_gun_kmh else 35.0
        if pitching_point is not None:
            vx0_init = (pitching_point.x - 20.0) / dt_pre
            vy0_init = (pitching_point.y) / dt_pre
        else:
            vx0_init = -speed_init_ms * 0.98
            vy0_init = 0.0
        vz0_init = (r_ball - 2.15 + 0.5 * 9.81 * dt_pre**2) / dt_pre

        # Theta vector:
        # [0] X0: release X (m)
        # [1] Y0: release Y (m)
        # [2] Z0: release Z (m)
        # [3] Vx0: release Vx (m/s)
        # [4] Vy0: release Vy (m/s)
        # [5] Vz0: release Vz (m/s)
        # [6] k_drag: drag coefficient
        # [7] swing: lateral swing accel (m/s^2)
        # [8] tb: bounce time (s)
        # [9] e: restitution
        # [10] mu_x: along-pitch friction
        # [11] seam_kick: lateral kick (m/s)
        theta0 = np.array([
            20.0,            # X0
            0.0,             # Y0
            2.15,            # Z0
            vx0_init,        # Vx0
            vy0_init,        # Vy0
            vz0_init,        # Vz0
            self.physics.default_k, # k_drag
            0.0,             # swing
            t_b_init,        # tb
            0.60,            # e
            0.20,            # mu_x
            0.0,             # seam_kick
        ], dtype=np.float64)

        lower_bounds = np.array([
            18.0, -1.0, self.cfg.fitting.release_height_min,
            -45.0, -4.0, -10.0,
            0.001, -3.0,
            t_b_init - 0.08, 0.40, 0.05, -3.0
        ])
        upper_bounds = np.array([
            22.0, 1.0, self.cfg.fitting.release_height_max,
            -18.0, 4.0, 5.0,
            0.007, 3.0,
            t_b_init + 0.08, 0.80, 0.40, 3.0
        ])

        # Ensure theta0 is strictly within bounds
        theta0 = np.clip(theta0, lower_bounds + 1e-4, upper_bounds - 1e-4)

        eval_times = np.array([track[i].timestamp for i in fit_indices])
        observed_uv = np.array([[track[i].x, track[i].y] for i in fit_indices])
        active_poses = [camera_poses[i] for i in fit_indices]

        def residual_fn(theta: np.ndarray) -> np.ndarray:
            sim_pos = self._simulate_path(theta, eval_times, t_rel)
            residuals = []
            for j, pose in enumerate(active_poses):
                uv_proj = pose.project(sim_pos[j].reshape(1, 3))[0]
                residuals.append((uv_proj[0] - observed_uv[j, 0]) / 2.0)
                residuals.append((uv_proj[1] - observed_uv[j, 1]) / 2.0)

            if pitching_point is not None:
                _, p_tb_eval, _ = self.physics.integrate_flight(
                    np.concatenate([theta[:3], theta[3:6]]),
                    (t_rel, theta[8]),
                    PhysicsParams(k_drag=theta[6], swing_accel=theta[7]),
                )
                residuals.append((p_tb_eval[-1, 0] - pitching_point.x) / 0.05)
                residuals.append((p_tb_eval[-1, 1] - pitching_point.y) / 0.05)

            # Prior penalties
            # Release height prior centered at 2.1 m
            residuals.append((theta[2] - 2.10) / 0.20)
            # Speed gun prior
            speed_ms = np.linalg.norm(theta[3:6])
            if speed_gun_kmh:
                target_ms = speed_gun_kmh / 3.6
                residuals.append((speed_ms - target_ms) / (self.cfg.fitting.default_speed_prior_sigma_kmh / 3.6))
            else:
                # Soft prior around 125 km/h
                residuals.append((speed_ms - 35.0) / 10.0)

            # Restitution prior around 0.60
            residuals.append((theta[9] - 0.60) / 0.10)
            # Drag prior around physical k
            residuals.append((theta[6] - self.physics.default_k) / 0.001)

            return np.array(residuals, dtype=np.float64)

        # Solve nonlinear least squares with robust Huber loss
        opt_res = least_squares(
            residual_fn,
            theta0,
            bounds=(lower_bounds, upper_bounds),
            loss="huber",
            f_scale=self.cfg.fitting.huber_loss_delta,
            max_nfev=150,
        )

        theta_opt = opt_res.x

        # Compute parameter covariance from Jacobian: Cov = (J^T J)^-1 * s^2
        J = opt_res.jac
        dof = max(len(opt_res.fun) - len(theta_opt), 1)
        s_sq = 2.0 * opt_res.cost / dof
        try:
            param_cov = np.linalg.pinv(J.T @ J) * s_sq
        except Exception:
            param_cov = np.eye(len(theta_opt)) * 0.05

        # Unpack optimal parameters
        p_rel = np.array([theta_opt[0], theta_opt[1], theta_opt[2]])
        v_rel = np.array([theta_opt[3], theta_opt[4], theta_opt[5]])
        speed_rel_kmh = float(np.linalg.norm(v_rel) * 3.6)
        params_pre = PhysicsParams(
            k_drag=float(theta_opt[6]),
            swing_accel=float(theta_opt[7]),
        )
        tb_opt = float(theta_opt[8])
        e_opt = float(theta_opt[9])
        mu_x_opt = float(theta_opt[10])
        seam_kick_opt = float(theta_opt[11])

        # Integrate pre-bounce trajectory to bounce time
        ts_pre, pos_pre, vel_pre = self.physics.integrate_flight(
            initial_state=np.concatenate([p_rel, v_rel]),
            t_span=(t_rel, tb_opt),
            params=params_pre,
            dt=0.002,
        )
        p_bounce = pos_pre[-1].copy()
        p_bounce[2] = r_ball
        if pitching_point is not None:
            p_bounce[0] = pitching_point.x
            p_bounce[1] = pitching_point.y
        v_bounce_before = vel_pre[-1].copy()

        # Post-bounce collision state
        params_post = PhysicsParams(
            k_drag=float(theta_opt[6]),
            swing_accel=float(theta_opt[7]),
            restitution_e=e_opt,
            friction_x=mu_x_opt,
            friction_y=0.15,
            seam_lateral_kick=seam_kick_opt,
        )
        v_bounce_after = self.physics.apply_bounce_collision(v_bounce_before, params_post)

        # Integrate to striker stump plane X = 0
        t_stump, p_stump, v_stump, ts_post, pos_post = self.physics.integrate_to_stump_plane(
            p_start=p_bounce,
            v_start=v_bounce_after,
            t_start=tb_opt,
            params=params_post,
            target_x=0.0,
            dt=0.002,
        )

        # Combine full dense trajectory
        full_ts = np.concatenate([ts_pre, ts_post[1:]])
        full_pos = np.concatenate([pos_pre, pos_post[1:]])

        # Propagate parameter covariance to stump plane (Y_stump, Z_stump)
        stump_cov = self._propagate_covariance_to_stumps(theta_opt, param_cov, t_rel)

        # Mean reprojection error on observations
        sim_obs = self._simulate_path(theta_opt, eval_times, t_rel)
        errors = []
        for j, pose in enumerate(active_poses):
            uv_p = pose.project(sim_obs[j].reshape(1, 3))[0]
            err = np.linalg.norm(uv_p - observed_uv[j])
            errors.append(err)
        mean_err = float(np.mean(errors)) if errors else 0.0

        return TrajectoryFitResult(
            p_release=p_rel,
            v_release=v_rel,
            speed_release_kmh=speed_rel_kmh,
            bounce_time=tb_opt,
            p_bounce=p_bounce,
            v_bounce_before=v_bounce_before,
            v_bounce_after=v_bounce_after,
            k_drag=float(theta_opt[6]),
            swing_accel=float(theta_opt[7]),
            restitution_e=e_opt,
            friction_x=mu_x_opt,
            seam_lateral_kick=seam_kick_opt,
            t_stump=t_stump,
            p_stump=p_stump,
            v_stump=v_stump,
            stump_plane_cov=stump_cov,
            timestamps=full_ts,
            trajectory_3d=full_pos,
            param_covariance=param_cov,
            mean_reprojection_error_px=mean_err,
            is_converged=bool(opt_res.success),
        )

    def _simulate_path(self, theta: np.ndarray, eval_times: np.ndarray, t_rel: float) -> np.ndarray:
        """Evaluates 3D trajectory positions at specified evaluation timestamps."""
        r_ball = self.cfg.ball.radius
        p_rel = theta[:3]
        v_rel = theta[3:6]
        k_drag = theta[6]
        swing = theta[7]
        tb = theta[8]
        e = theta[9]
        mu_x = theta[10]
        seam_kick = theta[11]

        params_pre = PhysicsParams(k_drag=k_drag, swing_accel=swing)
        params_post = PhysicsParams(
            k_drag=k_drag,
            swing_accel=swing,
            restitution_e=e,
            friction_x=mu_x,
            friction_y=0.15,
            seam_lateral_kick=seam_kick,
        )

        positions = np.zeros((len(eval_times), 3))
        # Mask pre vs post
        pre_mask = eval_times <= tb
        post_mask = ~pre_mask

        if np.any(pre_mask):
            _, pos_pre, _ = self.physics.integrate_flight(
                np.concatenate([p_rel, v_rel]),
                (t_rel, max(float(np.max(eval_times[pre_mask])), tb)),
                params_pre,
                eval_times=eval_times[pre_mask],
            )
            positions[pre_mask] = pos_pre[: np.sum(pre_mask)]

        # Pre-bounce end state at tb
        _, pos_tb, vel_tb = self.physics.integrate_flight(
            np.concatenate([p_rel, v_rel]),
            (t_rel, tb),
            params_pre,
        )
        p_b = pos_tb[-1]
        p_b[2] = r_ball
        v_b_after = self.physics.apply_bounce_collision(vel_tb[-1], params_post)

        if np.any(post_mask):
            _, pos_post, _ = self.physics.integrate_flight(
                np.concatenate([p_b, v_b_after]),
                (tb, float(np.max(eval_times[post_mask]))),
                params_post,
                eval_times=eval_times[post_mask],
            )
            positions[post_mask] = pos_post[: np.sum(post_mask)]

        return positions

    def _propagate_covariance_to_stumps(
        self,
        theta_opt: np.ndarray,
        param_cov: np.ndarray,
        t_rel: float,
    ) -> np.ndarray:
        """Computes 2x2 covariance of predicted (Y, Z) at striker stump plane X = 0."""
        # Numerical Jacobian of stump-plane arrival [Y_stump, Z_stump] w.r.t. theta
        eps = 1e-4
        P = len(theta_opt)
        J_stump = np.zeros((2, P))

        base_res = self._eval_stump_arrival(theta_opt, t_rel)

        for p_idx in range(P):
            th_plus = theta_opt.copy()
            th_plus[p_idx] += eps
            res_plus = self._eval_stump_arrival(th_plus, t_rel)
            J_stump[:, p_idx] = (res_plus - base_res) / eps

        cov_2x2 = J_stump @ param_cov @ J_stump.T

        # Regularize to guarantee positive definiteness
        cov_2x2 += np.diag([0.001**2, 0.001**2])
        return cov_2x2

    def _eval_stump_arrival(self, theta: np.ndarray, t_rel: float) -> np.ndarray:
        """Helper to compute [Y_stump, Z_stump] at X = 0 for parameter vector theta."""
        r_ball = self.cfg.ball.radius
        p_rel = theta[:3]
        v_rel = theta[3:6]
        params_pre = PhysicsParams(k_drag=theta[6], swing_accel=theta[7])
        tb = theta[8]
        params_post = PhysicsParams(
            k_drag=theta[6],
            swing_accel=theta[7],
            restitution_e=theta[9],
            friction_x=theta[10],
            friction_y=0.15,
            seam_lateral_kick=theta[11],
        )

        _, pos_tb, vel_tb = self.physics.integrate_flight(
            np.concatenate([p_rel, v_rel]),
            (t_rel, tb),
            params_pre,
        )
        p_b = pos_tb[-1]
        p_b[2] = r_ball
        v_b_after = self.physics.apply_bounce_collision(vel_tb[-1], params_post)

        _, p_stump, _, _, _ = self.physics.integrate_to_stump_plane(
            p_start=p_b,
            v_start=v_b_after,
            t_start=tb,
            params=params_post,
            target_x=0.0,
        )
        return p_stump[1:3]  # [Y_stump, Z_stump]
