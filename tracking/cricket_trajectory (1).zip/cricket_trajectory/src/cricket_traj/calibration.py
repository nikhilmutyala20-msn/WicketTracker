"""Per-frame camera calibration, homography decomposition, PnP, feature tracking, line refinement, and RTS smoothing."""

from dataclasses import dataclass, field
import logging
from typing import Dict, List, Optional, Tuple
import cv2
import numpy as np
from scipy.optimize import minimize_scalar

from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.interfaces import PitchLandmarks

logger = logging.getLogger(__name__)


@dataclass
class CameraPose:
    """Pinhole camera intrinsics and extrinsics for a single frame."""
    K: np.ndarray                          # (3, 3) intrinsic matrix
    R: np.ndarray                          # (3, 3) rotation matrix
    t: np.ndarray                          # (3, 1) translation vector
    reprojection_error: float = 0.0        # Mean pixel error across landmarks
    is_valid: bool = True
    focal_length: float = 0.0

    @property
    def camera_center(self) -> np.ndarray:
        """3D position of camera optical center in pitch coordinates: C = -R^T * t."""
        return (-self.R.T @ self.t).flatten()

    def project(self, points_3d: np.ndarray) -> np.ndarray:
        """Project (N, 3) world coordinates to (N, 2) image coordinates."""
        pts = np.atleast_2d(points_3d)
        if pts.shape[1] != 3:
            raise ValueError(f"Expected shape (N, 3), got {pts.shape}")
        
        # P_cam = R * P + t
        p_cam = (self.R @ pts.T) + self.t  # (3, N)
        # Avoid division by zero
        z = np.clip(p_cam[2, :], 1e-4, None)
        u = (self.K[0, 0] * p_cam[0, :] + self.K[0, 2] * z) / z
        v = (self.K[1, 1] * p_cam[1, :] + self.K[1, 2] * z) / z
        return np.column_stack([u, v])

    def ray(self, u: float, v: float) -> Tuple[np.ndarray, np.ndarray]:
        """Compute ray origin C and unit direction d in pitch coordinates for pixel (u, v)."""
        C = self.camera_center
        p_norm = np.linalg.inv(self.K) @ np.array([u, v, 1.0], dtype=np.float64)
        d_world = self.R.T @ p_norm
        d_unit = d_world / np.linalg.norm(d_world)
        return C, d_unit


class PitchCalibrator:
    """Solves per-frame camera pose from pitch landmarks, feature tracking, line refinement, and RTS smoothing."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG

    def calibrate_from_landmarks(
        self,
        landmarks: PitchLandmarks,
        image_shape: Tuple[int, int],
        prior_focal_length: Optional[float] = None,
    ) -> CameraPose:
        """Estimate K, R, t from 2D pitch landmarks for a single frame."""
        h, w = image_shape
        cx, cy = w / 2.0, h / 2.0
        
        pts_3d, pts_2d = landmarks.get_correspondences()
        if len(pts_3d) < 4:
            # Fallback default pose
            f = prior_focal_length if prior_focal_length else (w * 1.5)
            K = np.array([[f, 0, cx], [0, f, cy], [0, 0, 1.0]], dtype=np.float64)
            R = np.eye(3, dtype=np.float64)
            t = np.array([[0.0], [-10.0], [5.0]], dtype=np.float64)
            return CameraPose(K=K, R=R, t=t, reprojection_error=999.0, is_valid=False, focal_length=f)

        # Estimate focal length if not provided
        f_est = self._estimate_focal_length(pts_3d, pts_2d, cx, cy)
        f = f_est if (f_est is not None and 400.0 < f_est < 12000.0) else (prior_focal_length if prior_focal_length else (w * 1.5))
        K = np.array([[f, 0, cx], [0, f, cy], [0, 0, 1.0]], dtype=np.float64)

        # Separate coplanar vs 3D points
        z_vals = pts_3d[:, 2]
        has_3d = np.any(np.abs(z_vals) > 0.05)

        if has_3d and len(pts_3d) >= 4:
            # PnP with RANSAC
            dist_coeffs = np.zeros(4, dtype=np.float64)
            success, rvec, tvec, inliers = cv2.solvePnPRansac(
                pts_3d.astype(np.float64),
                pts_2d.astype(np.float64),
                K,
                dist_coeffs,
                flags=cv2.SOLVEPNP_EPNP,
                reprojectionError=self.cfg.camera.reprojection_error_thresh_px,
            )
            if success and rvec is not None and tvec is not None:
                # Refine with Levenberg-Marquardt
                try:
                    rvec, tvec = cv2.solvePnPRefineLM(
                        pts_3d[inliers.flatten()].astype(np.float64),
                        pts_2d[inliers.flatten()].astype(np.float64),
                        K,
                        dist_coeffs,
                        rvec,
                        tvec,
                    )
                except Exception:
                    pass
                R, _ = cv2.Rodrigues(rvec)
                t = tvec.reshape(3, 1)
            else:
                R, t = self._decompose_planar_homography(pts_3d, pts_2d, K)
        else:
            R, t = self._decompose_planar_homography(pts_3d, pts_2d, K)

        pose = CameraPose(K=K, R=R, t=t, focal_length=f)
        proj_2d = pose.project(pts_3d)
        err = float(np.mean(np.linalg.norm(proj_2d - pts_2d, axis=1)))
        pose.reprojection_error = err
        pose.is_valid = err < self.cfg.camera.reprojection_error_thresh_px * 2.0
        return pose

    def _estimate_focal_length(
        self,
        pts_3d: np.ndarray,
        pts_2d: np.ndarray,
        cx: float,
        cy: float,
    ) -> float:
        """Estimate focal length from ground plane homography decomposition constraint."""
        # Find points on pitch plane Z = 0
        mask_z0 = np.abs(pts_3d[:, 2]) < 0.05
        if np.sum(mask_z0) >= 4:
            src_xy = pts_3d[mask_z0, :2]
            dst_uv = pts_2d[mask_z0]
            H, _ = cv2.findHomography(src_xy, dst_uv, cv2.RANSAC, 4.0)
            if H is not None:
                # Direct closed-form vanishing constraint
                # Shift origin to image center
                T = np.array([[1, 0, -cx], [0, 1, -cy], [0, 0, 1]], dtype=np.float64)
                H_c = T @ H
                h1 = H_c[:, 0]
                h2 = H_c[:, 1]
                # Orthogonality constraint: (K^-1 h1)^T (K^-1 h2) = 0
                # (h1[0]*h2[0] + h1[1]*h2[1])/f^2 + h1[2]*h2[2] = 0
                num = -(h1[0] * h2[0] + h1[1] * h2[1])
                den = h1[2] * h2[2]
                if den != 0 and (num / den) > 0:
                    f_est = np.sqrt(num / den)
                    if 400.0 < f_est < 12000.0:
                        return float(f_est)

        # Default fallback to broadcast telephoto guess (~25 deg FOV)
        fov_rad = np.radians(self.cfg.camera.fov_guess_deg)
        return float((cx) / np.tan(fov_rad / 2.0))

    def _decompose_planar_homography(
        self,
        pts_3d: np.ndarray,
        pts_2d: np.ndarray,
        K: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Decompose homography on Z=0 into rotation R and translation t."""
        mask_z0 = np.abs(pts_3d[:, 2]) < 0.05
        src_xy = pts_3d[mask_z0, :2] if np.sum(mask_z0) >= 4 else pts_3d[:, :2]
        dst_uv = pts_2d[mask_z0] if np.sum(mask_z0) >= 4 else pts_2d

        H, _ = cv2.findHomography(src_xy, dst_uv, cv2.RANSAC, 4.0)
        if H is None:
            return np.eye(3), np.array([[0.0], [-10.0], [5.0]])

        K_inv = np.linalg.inv(K)
        h1 = H[:, 0]
        h2 = H[:, 1]
        h3 = H[:, 2]

        scale = 1.0 / np.linalg.norm(K_inv @ h1)
        r1 = scale * (K_inv @ h1)
        r2 = scale * (K_inv @ h2)
        r3 = np.cross(r1, r2)
        t = scale * (K_inv @ h3).reshape(3, 1)

        # Project rotation to SO(3) via SVD
        R_approx = np.column_stack([r1, r2, r3])
        U, _, Vt = np.linalg.svd(R_approx)
        R = U @ Vt
        if np.linalg.det(R) < 0:
            U[:, 2] *= -1
            R = U @ Vt

        # Ensure camera is above pitch (Z_cam > 0 in world coordinate system)
        C = -R.T @ t
        if C[2, 0] < 0:
            R = -R
            t = -t
        return R, t

    def calibrate_sequence(
        self,
        frames: List[np.ndarray],
        landmarks_list: List[PitchLandmarks],
        mask: Optional[np.ndarray] = None,
    ) -> List[CameraPose]:
        """Calibrates moving camera across a sequence with feature tracking and RTS smoothing."""
        num_frames = len(frames)
        if num_frames == 0:
            return []

        h, w = frames[0].shape[:2]
        raw_poses: List[CameraPose] = []
        last_good_f = None

        # 1. Landmark-based initial solve
        for i in range(num_frames):
            lm = landmarks_list[i] if i < len(landmarks_list) else PitchLandmarks()
            pose = self.calibrate_from_landmarks(lm, (h, w), prior_focal_length=last_good_f)
            if pose.is_valid:
                last_good_f = pose.focal_length
            raw_poses.append(pose)

        # 2. Inter-frame feature tracking for missing/invalid poses
        orb = cv2.ORB_create(nfeatures=500)
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

        for i in range(1, num_frames):
            if not raw_poses[i].is_valid and raw_poses[i - 1].is_valid:
                # Estimate relative motion between frame i-1 and i
                g1 = cv2.cvtColor(frames[i - 1], cv2.COLOR_BGR2GRAY)
                g2 = cv2.cvtColor(frames[i], cv2.COLOR_BGR2GRAY)
                kp1, des1 = orb.detectAndCompute(g1, mask)
                kp2, des2 = orb.detectAndCompute(g2, mask)
                if des1 is not None and des2 is not None and len(des1) >= 8 and len(des2) >= 8:
                    matches = bf.match(des1, des2)
                    if len(matches) >= 8:
                        pts1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 2)
                        pts2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 2)
                        E, mask_e = cv2.findEssentialMat(pts1, pts2, raw_poses[i - 1].K, method=cv2.RANSAC, prob=0.999, threshold=2.0)
                        if E is not None:
                            _, R_rel, t_rel, _ = cv2.recoverPose(E, pts1, pts2, raw_poses[i - 1].K, mask=mask_e)
                            # Chain pose
                            R_chain = R_rel @ raw_poses[i - 1].R
                            t_chain = R_rel @ raw_poses[i - 1].t + t_rel * 0.1
                            raw_poses[i] = CameraPose(
                                K=raw_poses[i - 1].K.copy(),
                                R=R_chain,
                                t=t_chain,
                                focal_length=raw_poses[i - 1].focal_length,
                                is_valid=True,
                                reprojection_error=raw_poses[i - 1].reprojection_error + 1.0,
                            )

        # 3. RTS Smoothing on camera pose parameters (Rodrigues rotation, translation, focal length)
        smoothed_poses = self._rts_smooth_poses(raw_poses, (h, w))
        return smoothed_poses

    def _rts_smooth_poses(self, poses: List[CameraPose], image_shape: Tuple[int, int]) -> List[CameraPose]:
        """Bidirectional Kalman filter + RTS smoother on [rvec (3), tvec (3), focal_length (1)]."""
        N = len(poses)
        if N <= 2:
            return poses

        h, w = image_shape
        cx, cy = w / 2.0, h / 2.0

        # State: 7 parameters [rx, ry, rz, tx, ty, tz, f]
        dim = 7
        measurements = np.zeros((N, dim), dtype=np.float64)
        valid_mask = np.zeros(N, dtype=bool)

        for i, p in enumerate(poses):
            rvec, _ = cv2.Rodrigues(p.R)
            measurements[i, :3] = rvec.flatten()
            measurements[i, 3:6] = p.t.flatten()
            measurements[i, 6] = p.focal_length
            valid_mask[i] = p.is_valid

        # Fill invalid measurements with linear interpolation
        for d in range(dim):
            valid_idx = np.where(valid_mask)[0]
            if len(valid_idx) > 0:
                measurements[:, d] = np.interp(np.arange(N), valid_idx, measurements[valid_idx, d])
            else:
                measurements[:, d] = np.zeros(N)

        # Kalman Filter Forward Pass
        x_pred = np.zeros((N, dim))
        P_pred = np.zeros((N, dim, dim))
        x_filt = np.zeros((N, dim))
        P_filt = np.zeros((N, dim, dim))

        Q = np.diag([1e-3, 1e-3, 1e-3, 1e-2, 1e-2, 1e-2, 10.0])      # Process noise
        R_meas = np.diag([1e-4, 1e-4, 1e-4, 1e-3, 1e-3, 1e-3, 1.0])  # Measurement noise

        x = measurements[0].copy()
        P = np.eye(dim) * 1.0

        for k in range(N):
            if k == 0:
                x_pred[k] = x
                P_pred[k] = P
            else:
                x_pred[k] = x_filt[k - 1]
                P_pred[k] = P_filt[k - 1] + Q

            # Update
            z = measurements[k]
            y = z - x_pred[k]
            S = P_pred[k] + (R_meas if valid_mask[k] else R_meas * 100.0)
            K_gain = P_pred[k] @ np.linalg.inv(S)
            x_filt[k] = x_pred[k] + K_gain @ y
            P_filt[k] = (np.eye(dim) - K_gain) @ P_pred[k]

        # RTS Backward Pass
        x_smooth = np.zeros((N, dim))
        P_smooth = np.zeros((N, dim, dim))
        x_smooth[-1] = x_filt[-1]
        P_smooth[-1] = P_filt[-1]

        for k in range(N - 2, -1, -1):
            C = P_filt[k] @ np.linalg.inv(P_pred[k + 1])
            x_smooth[k] = x_filt[k] + C @ (x_smooth[k + 1] - x_pred[k + 1])
            P_smooth[k] = P_filt[k] + C @ (P_smooth[k + 1] - P_pred[k + 1]) @ C.T

        # Reconstruct smoothed CameraPose objects
        smoothed_poses: List[CameraPose] = []
        for i in range(N):
            # If original landmark solve was highly confident, preserve it
            if poses[i].is_valid and poses[i].reprojection_error < 3.0:
                smoothed_poses.append(poses[i])
                continue

            rvec = x_smooth[i, :3]
            tvec = x_smooth[i, 3:6].reshape(3, 1)
            f = max(float(x_smooth[i, 6]), 100.0)
            R, _ = cv2.Rodrigues(rvec)
            K = np.array([[f, 0, cx], [0, f, cy], [0, 0, 1.0]], dtype=np.float64)
            smoothed_poses.append(
                CameraPose(
                    K=K,
                    R=R,
                    t=tvec,
                    reprojection_error=poses[i].reprojection_error,
                    is_valid=True,
                    focal_length=f,
                )
            )

        return smoothed_poses
