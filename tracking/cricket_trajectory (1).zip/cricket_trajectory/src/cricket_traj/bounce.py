"""Pitching point prediction via ray-plane intersection or pre-bounce physics extrapolation, with covariance."""

from dataclasses import dataclass
import logging
from typing import Optional, Tuple
import cv2
import numpy as np

from cricket_traj.calibration import CameraPose
from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.physics import BallPhysics, PhysicsParams

logger = logging.getLogger(__name__)


@dataclass
class PitchingPoint:
    """Estimated pitching (bounce) location on the cricket pitch."""
    x: float                           # Along-pitch coordinate (m from striker stumps)
    y: float                           # Lateral coordinate (m from center)
    z: float                           # Height above pitch surface (m, equal to ball radius)
    covariance: np.ndarray             # (2, 2) covariance matrix for (x, y)
    distance_from_stumps: float        # Distance to striker stumps: equal to x
    is_observed: bool                  # True if directly visible in frame
    timestamp: float                   # Time of bounce (seconds)

    @property
    def label(self) -> str:
        return f"PITCHED {self.distance_from_stumps:.2f} m from stumps"


class BouncePredictor:
    """Computes pitching point from camera ray intersection or pre-bounce physics extrapolation."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG
        self.physics = BallPhysics(self.cfg)

    def predict_observed_bounce(
        self,
        bounce_pixel: Tuple[float, float],
        camera_pose: CameraPose,
        timestamp: float,
        pixel_noise_sigma: float = 1.0,
    ) -> PitchingPoint:
        """Intersects camera ray at bounce frame with plane Z = ball_radius."""
        u, v = bounce_pixel
        r_ball = self.cfg.ball.radius
        C, d = camera_pose.ray(u, v)

        if abs(d[2]) < 1e-5:
            # Ray is parallel to pitch surface, fallback
            return PitchingPoint(
                x=7.5,
                y=0.0,
                z=r_ball,
                covariance=np.diag([0.5, 0.1]),
                distance_from_stumps=7.5,
                is_observed=False,
                timestamp=timestamp,
            )

        # C_z + lam * d_z = r_ball
        lam = (r_ball - C[2]) / d[2]
        x_bounce = float(C[0] + lam * d[0])
        y_bounce = float(C[1] + lam * d[1])

        # Compute numerical Jacobian d(x, y) / d(u, v) for covariance propagation
        delta = 1.0
        _, d_u = camera_pose.ray(u + delta, v)
        lam_u = (r_ball - C[2]) / d_u[2]
        xu = C[0] + lam_u * d_u[0]
        yu = C[1] + lam_u * d_u[1]

        _, d_v = camera_pose.ray(u, v + delta)
        lam_v = (r_ball - C[2]) / d_v[2]
        xv = C[0] + lam_v * d_v[0]
        yv = C[1] + lam_v * d_v[1]

        J = np.array([
            [(xu - x_bounce) / delta, (xv - x_bounce) / delta],
            [(yu - y_bounce) / delta, (yv - y_bounce) / delta],
        ], dtype=np.float64)

        Sigma_px = np.diag([pixel_noise_sigma**2, pixel_noise_sigma**2])
        cov_xy = J @ Sigma_px @ J.T + np.diag([0.01**2, 0.005**2])  # Add base calibration uncertainty

        return PitchingPoint(
            x=x_bounce,
            y=y_bounce,
            z=r_ball,
            covariance=cov_xy,
            distance_from_stumps=x_bounce,
            is_observed=True,
            timestamp=timestamp,
        )

    def predict_unobserved_bounce(
        self,
        p0: np.ndarray,
        v0: np.ndarray,
        t0: float,
        params: PhysicsParams,
        param_cov: Optional[np.ndarray] = None,
    ) -> PitchingPoint:
        """Solves for bounce position by integrating pre-bounce arc to Z = ball_radius."""
        t_bounce, p_bounce, _ = self.physics.find_pitch_bounce(p0, v0, t0, params)
        r_ball = self.cfg.ball.radius

        # Covariance approximation from parameter uncertainty
        if param_cov is not None and param_cov.shape[0] >= 6:
            # Perturb initial state to estimate sensitivity
            delta = 0.05
            p_perturbed = p0.copy()
            p_perturbed[2] -= delta
            tb_p, pb_p, _ = self.physics.find_pitch_bounce(p_perturbed, v0, t0, params)
            cov_xy = np.diag([max(abs(pb_p[0] - p_bounce[0]), 0.05)**2, 0.02**2])
        else:
            cov_xy = np.diag([0.15**2, 0.05**2])

        return PitchingPoint(
            x=float(p_bounce[0]),
            y=float(p_bounce[1]),
            z=r_ball,
            covariance=cov_xy,
            distance_from_stumps=float(p_bounce[0]),
            is_observed=False,
            timestamp=t_bounce,
        )

    def draw_on_frame(
        self,
        frame: np.ndarray,
        camera_pose: CameraPose,
        pitching_point: PitchingPoint,
        radius_m: float = 0.20,
    ) -> np.ndarray:
        """Draws pitching circle on the pitch surface and broadcast label on the video frame."""
        out = frame.copy()
        if not camera_pose.is_valid:
            return out

        # Generate 3D circle points on pitch surface Z = 0
        angles = np.linspace(0, 2 * np.pi, 36)
        cx, cy = pitching_point.x, pitching_point.y
        circle_pts_3d = np.column_stack([
            cx + radius_m * np.cos(angles),
            cy + radius_m * np.sin(angles),
            np.zeros_like(angles),
        ])

        pts_2d = camera_pose.project(circle_pts_3d).astype(np.int32)
        center_2d = camera_pose.project(np.array([[cx, cy, 0.0]]))[0].astype(np.int32)

        # Draw glowing ring on pitch
        cv2.polylines(out, [pts_2d], isClosed=True, color=(0, 255, 255), thickness=3, lineType=cv2.LINE_AA)
        cv2.circle(out, tuple(center_2d), 4, (0, 255, 255), -1, lineType=cv2.LINE_AA)

        # Draw label card
        label = pitching_point.label
        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.55
        thickness = 2
        (tw, th), baseline = cv2.getTextSize(label, font, scale, thickness)

        lx = int(center_2d[0] - tw // 2)
        ly = int(center_2d[1] - 25)

        # Background badge
        pad = 6
        cv2.rectangle(
            out,
            (lx - pad, ly - th - pad),
            (lx + tw + pad, ly + baseline + pad),
            (20, 20, 20),
            -1,
        )
        cv2.rectangle(
            out,
            (lx - pad, ly - th - pad),
            (lx + tw + pad, ly + baseline + pad),
            (0, 255, 255),
            1,
        )
        cv2.putText(out, label, (lx, ly), font, scale, (255, 255, 255), thickness, lineType=cv2.LINE_AA)

        return out
