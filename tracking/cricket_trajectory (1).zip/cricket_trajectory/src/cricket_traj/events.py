"""Event detection: release frame, bounce frame with sub-frame timing, and pad impact detection."""

from dataclasses import dataclass
import logging
from typing import List, Optional, Tuple
import numpy as np

from cricket_traj.calibration import CameraPose
from cricket_traj.tracking import TrackPoint

logger = logging.getLogger(__name__)


@dataclass
class DeliveryEvents:
    """Critical event frames and timestamps during a cricket delivery."""
    release_frame: int
    release_time: float
    bounce_frame: int
    bounce_time: float             # Sub-frame estimated timestamp (seconds)
    bounce_is_observed: bool
    impact_frame: int
    impact_time: float
    has_pad_impact: bool = True


class EventDetector:
    """Detects delivery release, pitch bounce (with sub-frame resolution), and pad impact."""

    def __init__(
        self,
        min_flight_frames: int = 6,
        velocity_discontinuity_thresh: float = 3.0,
    ):
        self.min_flight_frames = min_flight_frames
        self.velocity_discontinuity_thresh = velocity_discontinuity_thresh

    def detect_events(
        self,
        track: List[TrackPoint],
        camera_poses: List[CameraPose],
        audio_samples: Optional[np.ndarray] = None,
        audio_sr: int = 44100,
    ) -> DeliveryEvents:
        N = len(track)
        if N < self.min_flight_frames:
            t0 = track[0].timestamp if track else 0.0
            return DeliveryEvents(
                release_frame=0,
                release_time=t0,
                bounce_frame=max(0, N // 2),
                bounce_time=t0 + 0.3,
                bounce_is_observed=False,
                impact_frame=max(0, N - 1),
                impact_time=t0 + 0.6,
                has_pad_impact=False,
            )

        ts = np.array([p.timestamp for p in track], dtype=np.float64)
        xs = np.array([p.x for p in track], dtype=np.float64)
        ys = np.array([p.y for p in track], dtype=np.float64)
        obs = np.array([p.is_observed for p in track], dtype=bool)

        # 1. Release Frame
        release_idx = 0

        # 2. Impact Frame: near end of track where ball stops / occluded by batsman
        impact_idx = N - 1
        last_obs = np.where(obs)[0]
        if len(last_obs) > 0:
            last_idx = int(last_obs[-1])
            if last_idx >= release_idx + self.min_flight_frames:
                impact_idx = last_idx

        # 3. Detect Bounce Frame
        # In broadcast view looking from behind bowler toward pitch:
        # Before bounce, ball descends towards pitch (increasing image y).
        # At bounce, ball rebounds upward (image y peaks and reverses / decreases).
        # Therefore, at bounce, velocity dy/dt experiences a sharp negative drop,
        # and acceleration d2y/dt2 has a strong negative spike.
        bounce_idx = -1
        search_start = max(release_idx + int(N * 0.40), 8)
        search_end = max(search_start + 1, impact_idx - 1)

        # Compute finite differences of y
        dy = np.diff(ys)
        ddy = np.diff(dy)

        # Look for most negative curvature / sharpest downward-to-upward reflection
        if len(ddy) > search_start:
            valid_end = min(search_end, len(ddy))
            window_ddy = ddy[search_start:valid_end]
            if len(window_ddy) > 0:
                best_sub_idx = int(np.argmin(window_ddy))
                bounce_idx = search_start + best_sub_idx + 1

        if bounce_idx < 0 or bounce_idx >= N:
            bounce_idx = (release_idx + impact_idx) // 2

        # 4. Refine Bounce with Sub-frame Time Estimation
        t_sub_bounce = self._estimate_subframe_bounce_time(ts, ys, bounce_idx)
        bounce_observed = bool(obs[bounce_idx])

        return DeliveryEvents(
            release_frame=release_idx,
            release_time=float(ts[release_idx]),
            bounce_frame=bounce_idx,
            bounce_time=float(t_sub_bounce),
            bounce_is_observed=bounce_observed,
            impact_frame=impact_idx,
            impact_time=float(ts[impact_idx]),
            has_pad_impact=True,
        )

    def _estimate_subframe_bounce_time(self, ts: np.ndarray, ys: np.ndarray, b_idx: int) -> float:
        N = len(ts)
        i1 = max(0, b_idx - 3)
        i2 = min(N, b_idx + 4)

        if b_idx - i1 < 2 or i2 - b_idx < 2:
            return float(ts[b_idx])

        t_pre = ts[i1 : b_idx + 1]
        y_pre = ys[i1 : b_idx + 1]
        p_pre = np.polyfit(t_pre, y_pre, 1)

        t_post = ts[b_idx:i2]
        y_post = ys[b_idx:i2]
        p_post = np.polyfit(t_post, y_post, 1)

        denom = p_pre[0] - p_post[0]
        if abs(denom) > 1e-4:
            t_inter = (p_post[1] - p_pre[1]) / denom
            dt_frame = abs(ts[min(b_idx + 1, N - 1)] - ts[max(b_idx - 1, 0)]) / 2.0
            if abs(t_inter - ts[b_idx]) <= 1.5 * dt_frame:
                return float(t_inter)

        return float(ts[b_idx])
