"""Configuration parameters and physical constants for Cricket Trajectory and LBW graphics."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Tuple, List, Optional
import yaml


@dataclass
class PitchConfig:
    length_between_stumps: float = 20.12     # Metres between striker (X=0) and bowler (X=20.12)
    width: float = 3.05                     # Pitch strip width (m)
    popping_crease_dist: float = 1.22        # Metres in front of stumps
    return_crease_half_width: float = 1.32   # Metres from pitch centerline (+-1.32 m)
    stump_width: float = 0.2286              # 22.86 cm total width across 3 stumps
    stump_height: float = 0.711              # 71.1 cm height of stumps
    bail_height: float = 0.035               # 3.5 cm clearance for bails
    corridor_half_width: float = 0.1143      # Half of stump width (0.2286 / 2)


@dataclass
class BallConfig:
    radius: float = 0.036                    # 3.6 cm radius (7.2 cm diameter)
    mass: float = 0.160                      # 160 grams
    cd: float = 0.45                         # Aerodynamic drag coefficient
    air_density: float = 1.20                # kg/m^3 (sea level standard)


@dataclass
class CameraConfig:
    default_fps: float = 50.0
    assumed_sensor_aspect: float = 16.0 / 9.0
    fov_guess_deg: float = 25.0
    min_reprojection_inliers: int = 4
    reprojection_error_thresh_px: float = 5.0


@dataclass
class TrackingConfig:
    top_k_candidates: int = 5
    corridor_x_min: float = -1.0
    corridor_x_max: float = 22.0
    corridor_y_max: float = 2.2
    corridor_z_max: float = 3.5
    viterbi_accel_weight: float = 1.0
    viterbi_dist_weight: float = 0.5
    viterbi_miss_penalty: float = 15.0


@dataclass
class FittingConfig:
    huber_loss_delta: float = 2.0
    release_height_min: float = 1.80
    release_height_max: float = 2.45
    speed_min_kmh: float = 70.0
    speed_max_kmh: float = 160.0
    default_speed_prior_sigma_kmh: float = 15.0


@dataclass
class LBWConfig:
    handedness: str = "right"                # "right" or "left"
    stump_half_width: float = 0.1143
    umpires_call_margin_m: float = 0.036     # 1 ball radius (3.6 cm)
    impact_forward_min_x: float = 0.10       # Must impact in front of stumps


@dataclass
class RenderConfig:
    actual_path_color: Tuple[int, int, int] = (0, 0, 230)       # Red BGR
    counterfactual_color: Tuple[int, int, int] = (230, 140, 20) # Blue BGR
    corridor_color: Tuple[int, int, int] = (200, 100, 30)       # Cyan/Blue BGR
    tube_radius_px: int = 5
    overlay_alpha: float = 0.75
    video_codec: str = "mp4v"


@dataclass
class Config:
    pitch: PitchConfig = field(default_factory=PitchConfig)
    ball: BallConfig = field(default_factory=BallConfig)
    camera: CameraConfig = field(default_factory=CameraConfig)
    tracking: TrackingConfig = field(default_factory=TrackingConfig)
    fitting: FittingConfig = field(default_factory=FittingConfig)
    lbw: LBWConfig = field(default_factory=LBWConfig)
    rendering: RenderConfig = field(default_factory=RenderConfig)

    @classmethod
    def load(cls, yaml_path: Optional[str | Path] = None) -> "Config":
        if yaml_path is None:
            # Check default locations
            candidates = [
                Path("config.yaml"),
                Path(__file__).resolve().parent.parent.parent / "config.yaml",
                Path(__file__).resolve().parent / "config.yaml",
            ]
            for c in candidates:
                if c.exists():
                    yaml_path = c
                    break

        if yaml_path is None or not Path(yaml_path).exists():
            return cls()

        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        pitch = PitchConfig(**data.get("pitch", {}))
        ball = BallConfig(**data.get("ball", {}))
        camera = CameraConfig(**data.get("camera", {}))
        tracking = TrackingConfig(**data.get("tracking", {}))
        fitting = FittingConfig(**data.get("fitting", {}))
        lbw = LBWConfig(**data.get("lbw", {}))
        rendering = RenderConfig(**data.get("rendering", {}))

        return cls(
            pitch=pitch,
            ball=ball,
            camera=camera,
            tracking=tracking,
            fitting=fitting,
            lbw=lbw,
            rendering=rendering,
        )


DEFAULT_CONFIG = Config.load()
