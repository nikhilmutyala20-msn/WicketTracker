"""Cricket ball 3D flight physics, aerodynamic drag, lateral swing, ground collision, and RK4 integration."""

from dataclasses import dataclass
import numpy as np
from typing import Callable, Optional, Tuple

from cricket_traj.config import Config, DEFAULT_CONFIG


@dataclass
class PhysicsParams:
    """Parameters governing aerodynamic flight and pitch bounce collision."""
    k_drag: float = 0.003435           # rho * Cd * A / (2 * m)
    swing_accel: float = 0.0           # Lateral acceleration a_y in m/s^2
    restitution_e: float = 0.60        # Coefficient of normal restitution
    friction_x: float = 0.20           # Fractional reduction in along-pitch velocity upon bounce
    friction_y: float = 0.15           # Fractional reduction in lateral velocity upon bounce
    seam_lateral_kick: float = 0.0     # Delta V_y imparted by pitch seam/spin (m/s)
    gravity: float = 9.80665


class BallPhysics:
    """Integrates 3D equations of motion for cricket ball using Runge-Kutta 4th Order (RK4)."""

    def __init__(self, config: Optional[Config] = None):
        self.cfg = config or DEFAULT_CONFIG
        # Compute baseline drag constant k = rho * Cd * A / (2 * m)
        r = self.cfg.ball.radius
        A = np.pi * r * r
        m = self.cfg.ball.mass
        rho = self.cfg.ball.air_density
        Cd = self.cfg.ball.cd
        self.default_k = (rho * Cd * A) / (2.0 * m)

    def equations_of_motion(
        self,
        t: float,
        state: np.ndarray,
        params: PhysicsParams,
    ) -> np.ndarray:
        """Computes d/dt [X, Y, Z, Vx, Vy, Vz].
        
        State: [X, Y, Z, Vx, Vy, Vz]
        dV/dt = g - k * |V| * V + [0, a_lateral, 0]
        """
        # pos = state[:3]
        vel = state[3:6]
        speed = np.linalg.norm(vel)

        # Aerodynamic drag deceleration
        drag_accel = -params.k_drag * speed * vel

        # Gravity (acting along -Z)
        grav_accel = np.array([0.0, 0.0, -params.gravity], dtype=np.float64)

        # Lateral swing acceleration (along Y)
        swing_accel = np.array([0.0, params.swing_accel, 0.0], dtype=np.float64)

        accel = drag_accel + grav_accel + swing_accel
        return np.concatenate([vel, accel])

    def rk4_step(
        self,
        t: float,
        state: np.ndarray,
        dt: float,
        params: PhysicsParams,
    ) -> np.ndarray:
        """Performs a single RK4 integration step."""
        f = lambda _t, _s: self.equations_of_motion(_t, _s, params)
        k1 = f(t, state)
        k2 = f(t + 0.5 * dt, state + 0.5 * dt * k1)
        k3 = f(t + 0.5 * dt, state + 0.5 * dt * k2)
        k4 = f(t + dt, state + dt * k3)
        return state + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)

    def integrate_flight(
        self,
        initial_state: np.ndarray,
        t_span: Tuple[float, float],
        params: PhysicsParams,
        eval_times: Optional[np.ndarray] = None,
        dt: float = 0.002,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Integrates free flight between t_span[0] and t_span[1].
        
        Returns:
            (timestamps, positions (N, 3), velocities (N, 3))
        """
        t0, t1 = t_span
        if t1 <= t0:
            return np.array([t0]), initial_state[:3].reshape(1, 3), initial_state[3:6].reshape(1, 3)

        if eval_times is not None:
            # Integrate up to max eval time
            target_ts = np.sort(eval_times[eval_times >= t0])
            if len(target_ts) == 0:
                target_ts = np.array([t0, t1])
        else:
            target_ts = np.linspace(t0, t1, int(max((t1 - t0) / dt, 2)))

        out_states = [initial_state.copy()]
        out_times = [t0]

        curr_t = t0
        curr_state = initial_state.copy()

        for next_t in target_ts[1:]:
            while curr_t < next_t - 1e-6:
                step_h = min(dt, next_t - curr_t)
                curr_state = self.rk4_step(curr_t, curr_state, step_h, params)
                curr_t += step_h
            out_times.append(next_t)
            out_states.append(curr_state.copy())

        out_ts = np.array(out_times)
        out_arr = np.array(out_states)
        return out_ts, out_arr[:, :3], out_arr[:, 3:6]

    def find_pitch_bounce(
        self,
        p0: np.ndarray,
        v0: np.ndarray,
        t0: float,
        params: PhysicsParams,
        max_t: float = 1.0,
        dt: float = 0.001,
    ) -> Tuple[float, np.ndarray, np.ndarray]:
        """Simulates pre-bounce arc to find exact time and state when Z(t) = ball_radius.
        
        Returns:
            (t_bounce, p_bounce, v_bounce_before)
        """
        r_ball = self.cfg.ball.radius
        curr_state = np.concatenate([p0, v0])
        curr_t = t0

        prev_state = curr_state.copy()
        prev_t = curr_t

        while curr_t < t0 + max_t:
            prev_state = curr_state.copy()
            prev_t = curr_t
            curr_state = self.rk4_step(curr_t, curr_state, dt, params)
            curr_t += dt

            # Check if crossed Z = r_ball while descending
            if curr_state[2] <= r_ball and curr_state[5] < 0:
                # Bisection to find exact root Z(t) = r_ball
                ta, tb = prev_t, curr_t
                sa, sb = prev_state.copy(), curr_state.copy()
                for _ in range(20):
                    t_mid = 0.5 * (ta + tb)
                    s_mid = self.rk4_step(ta, sa, t_mid - ta, params)
                    if s_mid[2] <= r_ball:
                        tb = t_mid
                        sb = s_mid
                    else:
                        ta = t_mid
                        sa = s_mid
                t_bounce = 0.5 * (ta + tb)
                s_bounce = self.rk4_step(ta, sa, t_bounce - ta, params)
                p_bounce = s_bounce[:3]
                p_bounce[2] = r_ball  # Clamp to ball radius
                v_bounce = s_bounce[3:6]
                return float(t_bounce), p_bounce, v_bounce

        # Fallback if no bounce detected within max_t
        return t0 + 0.35, curr_state[:3], curr_state[3:6]

    def apply_bounce_collision(
        self,
        v_before: np.ndarray,
        params: PhysicsParams,
    ) -> np.ndarray:
        """Applies restitution, along-pitch friction, and seam/spin lateral kick to velocity.
        
        V_before: [Vx, Vy, Vz]
        V_after: [
          (1 - friction_x) * Vx,
          (1 - friction_y) * Vy + seam_lateral_kick,
          -restitution_e * Vz
        ]
        """
        vx_after = (1.0 - params.friction_x) * v_before[0]
        vy_after = (1.0 - params.friction_y) * v_before[1] + params.seam_lateral_kick
        vz_after = -params.restitution_e * v_before[2]
        return np.array([vx_after, vy_after, vz_after], dtype=np.float64)

    def integrate_to_stump_plane(
        self,
        p_start: np.ndarray,
        v_start: np.ndarray,
        t_start: float,
        params: PhysicsParams,
        target_x: float = 0.0,
        max_time: float = 0.8,
        dt: float = 0.002,
    ) -> Tuple[float, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Integrates trajectory until ball center crosses striker stump plane X = target_x (0.0).
        
        Returns:
            (t_stump, p_stump, v_stump, all_ts, all_positions)
        """
        curr_state = np.concatenate([p_start, v_start])
        curr_t = t_start
        all_ts = [curr_t]
        all_pos = [p_start.copy()]

        prev_state = curr_state.copy()
        prev_t = curr_t

        while curr_t < t_start + max_time:
            prev_state = curr_state.copy()
            prev_t = curr_t
            curr_state = self.rk4_step(curr_t, curr_state, dt, params)
            curr_t += dt
            all_ts.append(curr_t)
            all_pos.append(curr_state[:3].copy())

            # In our pitch frame, striker is at X=0, bowler is at X=20.12, ball moves towards X=0
            # So ball crosses stump plane when X <= target_x
            if curr_state[0] <= target_x:
                # Interpolate exact crossing
                frac = (prev_state[0] - target_x) / max(prev_state[0] - curr_state[0], 1e-6)
                t_stump = prev_t + frac * (curr_t - prev_t)
                s_stump = prev_state + frac * (curr_state - prev_state)
                s_stump[0] = target_x
                all_ts[-1] = t_stump
                all_pos[-1] = s_stump[:3]
                return float(t_stump), s_stump[:3], s_stump[3:6], np.array(all_ts), np.array(all_pos)

        # Fallback if didn't reach X=0
        return curr_t, curr_state[:3], curr_state[3:6], np.array(all_ts), np.array(all_pos)
