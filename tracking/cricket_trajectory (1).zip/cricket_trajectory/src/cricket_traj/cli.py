"""Command Line Interface (CLI) for Hawk-Eye Cricket Trajectory tracking and LBW graphics."""

import argparse
import logging
from pathlib import Path
import sys
from typing import Optional
import numpy as np

from cricket_traj.adapters import GenericBallDetectorAdapter, GenericPitchDetectorAdapter
from cricket_traj.bounce import BouncePredictor
from cricket_traj.calibration import PitchCalibrator
from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.counterfactual import CounterfactualGenerator
from cricket_traj.events import EventDetector
from cricket_traj.fit import TrajectoryFitter
from cricket_traj.lbw import LBWClassifier
from cricket_traj.preprocess import VideoPreprocessor
from cricket_traj.render import HawkEyeRenderer
from cricket_traj.tracking import BallTracker

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("cricket_traj.cli")


def run_pipeline(
    video_path: str | Path,
    out_dir: str | Path,
    fps: Optional[float] = None,
    handedness: str = "right",
    speed_kmh: Optional[float] = None,
    debug: bool = False,
    ball_detector=None,
    pitch_detector=None,
    config: Optional[Config] = None,
) -> dict:
    """Executes full Hawk-Eye trajectory and LBW graphics pipeline on an input cricket video."""
    cfg = config or DEFAULT_CONFIG
    cfg.lbw.handedness = handedness

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if debug:
        (out_dir / "debug").mkdir(parents=True, exist_ok=True)

    renderer = HawkEyeRenderer(cfg)

    try:
        # Stage 1: Preprocess video
        logger.info(f"Stage 1: Preprocessing video {video_path}...")
        preprocessor = VideoPreprocessor()
        preproc_video = preprocessor.process(video_path, fps_override=fps)
        frames = preproc_video.frames
        timestamps = preproc_video.timestamps
        effective_fps = preproc_video.fps
        h, w = frames[0].shape[:2]

        # Stage 2: Pitch Landmark Detection & Camera Calibration
        logger.info("Stage 2: Pitch detection and camera calibration...")
        p_detector = pitch_detector or GenericPitchDetectorAdapter()
        landmarks_list = [p_detector.detect(f) for f in frames]

        calibrator = PitchCalibrator(cfg)
        camera_poses = calibrator.calibrate_sequence(frames, landmarks_list, mask=preproc_video.overlay_mask)

        # Stage 3: Ball Detection & Multi-Candidate Tracking
        logger.info("Stage 3: Ball detection and 3D corridor tracking...")
        b_detector = ball_detector or GenericBallDetectorAdapter()
        candidates_list = b_detector.detect(frames)

        tracker = BallTracker(cfg)
        track_points = tracker.track(candidates_list, camera_poses, timestamps, (h, w))

        # Stage 4: Event Detection (Release, Bounce, Impact)
        logger.info("Stage 4: Detecting delivery events...")
        event_detector = EventDetector()
        events = event_detector.detect_events(track_points, camera_poses)

        # Stage 5: Pitching Point Prediction
        logger.info("Stage 5: Pitching point estimation...")
        bounce_predictor = BouncePredictor(cfg)
        bounce_pt = track_points[events.bounce_frame]
        if events.bounce_is_observed and camera_poses[events.bounce_frame].is_valid:
            bx = bounce_pt.raw_x if bounce_pt.raw_x is not None else bounce_pt.x
            by = bounce_pt.raw_y if bounce_pt.raw_y is not None else bounce_pt.y
            pitching_point = bounce_predictor.predict_observed_bounce(
                bounce_pixel=(bx, by),
                camera_pose=camera_poses[events.bounce_frame],
                timestamp=events.bounce_time,
            )
        else:
            # Fallback will be finalized during joint physics fit
            pitching_point = None

        # Stage 6 & 7: Joint 3D Trajectory Physics Fit with Huber Loss
        logger.info("Stage 6 & 7: Nonlinear 3D trajectory fitting...")
        fitter = TrajectoryFitter(cfg)
        fit_res = fitter.fit(
            track=track_points,
            camera_poses=camera_poses,
            events=events,
            speed_gun_kmh=speed_kmh,
            pitching_point=pitching_point,
        )

        # If bounce was unobserved, update pitching point from fitted physics
        if pitching_point is None:
            pitching_point = bounce_predictor.predict_unobserved_bounce(
                p0=fit_res.p_release,
                v0=fit_res.v_release,
                t0=events.release_time,
                params=PhysicsParams(k_drag=fit_res.k_drag, swing_accel=fit_res.swing_accel),
                param_cov=fit_res.param_covariance,
            )

        # Stage 8: Counterfactual Trajectory (If ball had not turned/seamed)
        logger.info("Stage 8: Generating counterfactual trajectory...")
        cf_gen = CounterfactualGenerator(cfg)
        cf_traj = cf_gen.generate(fit_res)

        # Stage 9: LBW Verdict Rules
        logger.info("Stage 9: Evaluating Hawk-Eye LBW rules...")
        lbw_classifier = LBWClassifier(cfg)
        lbw_decision = lbw_classifier.evaluate(fit_res)

        # Stage 10: Rendering and Exports
        logger.info("Stage 10: Exporting visualizations...")
        overlay_mp4 = renderer.render_overlay_video(
            frames=frames,
            camera_poses=camera_poses,
            fit_res=fit_res,
            cf_traj=cf_traj,
            events=events,
            lbw_decision=lbw_decision,
            out_path=out_dir / "overlay.mp4",
            fps=effective_fps,
        )

        virtual_mp4 = renderer.render_virtual_view(
            fit_res=fit_res,
            cf_traj=cf_traj,
            lbw=lbw_decision,
            out_path=out_dir / "virtual_view.mp4",
            fps=effective_fps,
        )

        pitch_map_png = renderer.render_top_down_pitch_map(
            fit_res=fit_res,
            cf_traj=cf_traj,
            lbw=lbw_decision,
            out_path=out_dir / "pitch_map.png",
        )

        json_path = renderer.export_results_json(
            fit_res=fit_res,
            cf_traj=cf_traj,
            lbw=lbw_decision,
            events=events,
            camera_poses=camera_poses,
            track_points=track_points,
            out_path=out_dir / "result.json",
            pitching_point=pitching_point,
            status="SUCCESS",
        )

        logger.info(f"Pipeline successfully completed! LBW Verdict: {lbw_decision.overall_decision}")
        return {
            "status": "SUCCESS",
            "overlay_video": str(overlay_mp4),
            "virtual_video": str(virtual_mp4),
            "pitch_map": str(pitch_map_png),
            "result_json": str(json_path),
            "verdict": lbw_decision.overall_decision,
        }

    except Exception as e:
        logger.error(f"Pipeline encountered failure: {e}", exc_info=True)
        # Graceful degradation: generate result.json with degraded status
        fail_json = out_dir / "result.json"
        err_data = {
            "status": "DEGRADED",
            "failing_stage": str(sys.exc_info()[0].__name__ if sys.exc_info()[0] else "Unknown"),
            "error_message": str(e),
            "confidence": {"overall_quality": "REDUCED_CONFIDENCE"},
        }
        with open(fail_json, "w", encoding="utf-8") as f:
            import json
            json.dump(err_data, f, indent=2)
        return {
            "status": "DEGRADED",
            "result_json": str(fail_json),
            "error": str(e),
        }


def main():
    parser = argparse.ArgumentParser(description="Hawk-Eye Cricket Trajectory and LBW Graphics Pipeline")
    subparsers = parser.add_subparsers(dest="command")

    # Run command
    run_parser = subparsers.add_parser("run", help="Run trajectory tracking on a video clip")
    run_parser.add_argument("--video", type=str, required=True, help="Path to input cricket video clip (MP4)")
    run_parser.add_argument("--out", type=str, required=True, help="Output directory for generated graphics")
    run_parser.add_argument("--fps", type=float, default=None, help="Framerate override (e.g. 50)")
    run_parser.add_argument("--handedness", type=str, choices=["right", "left"], default="right", help="Batter handedness")
    run_parser.add_argument("--speed-kmh", type=float, default=None, help="Radar speed-gun prior in km/h")
    run_parser.add_argument("--debug", action="store_true", help="Save intermediate debug frames and residuals")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Generate synthetic cricket clip and run end-to-end demo")
    demo_parser.add_argument("--out", type=str, default="demo_out", help="Output directory for demo outputs")

    args = parser.parse_args()

    if args.command == "run":
        res = run_pipeline(
            video_path=args.video,
            out_dir=args.out,
            fps=args.fps,
            handedness=args.handedness,
            speed_kmh=args.speed_kmh,
            debug=args.debug,
        )
        print(f"Pipeline Result: {res['status']}")
    elif args.command == "demo":
        from examples.synthetic_delivery_generator import generate_synthetic_demo
        generate_synthetic_demo(out_dir=args.out)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
