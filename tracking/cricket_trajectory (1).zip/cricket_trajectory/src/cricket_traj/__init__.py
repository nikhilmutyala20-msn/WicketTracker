"""Cricket Trajectory tracking and Hawk-Eye LBW graphics package."""

__version__ = "0.1.0"
