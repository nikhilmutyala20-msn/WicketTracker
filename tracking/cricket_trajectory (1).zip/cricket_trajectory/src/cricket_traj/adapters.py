"""Adapter classes for integrating external ball and pitch detectors with classical OpenCV fallbacks."""

import logging
from typing import Any, Callable, Dict, List, Optional, Tuple
import cv2
import numpy as np

from cricket_traj.interfaces import (
    BallCandidate,
    BallDetector,
    PitchDetector,
    PitchLandmarks,
)

logger = logging.getLogger(__name__)


class GenericBallDetectorAdapter(BallDetector):
    """Adapter for custom ball detector models (e.g. YOLO, TrackNet, or custom CNNs).
    
    Accepts an arbitrary callable `detector_fn(frame: np.ndarray)` that outputs:
      - List of dicts with keys 'x', 'y', 'conf' (or 'confidence', 'score')
      - OR List of bounding boxes [x1, y1, x2, y2, conf]
      - OR (H, W) heatmap of ball probabilities
    """

    def __init__(
        self,
        detector_fn: Optional[Callable[[np.ndarray], Any]] = None,
        top_k: int = 5,
        min_conf: float = 0.1,
    ):
        self.detector_fn = detector_fn
        self.top_k = top_k
        self.min_conf = min_conf

    def detect(self, frames: List[np.ndarray]) -> List[List[BallCandidate]]:
        if self.detector_fn is None:
            # Fallback to simple blob/difference detection if no model is provided
            return [self._detect_fallback(f) for f in frames]

        results: List[List[BallCandidate]] = []
        for frame in frames:
            raw_out = self.detector_fn(frame)
            candidates = self._parse_raw_output(raw_out, frame.shape[:2])
            # Sort by confidence descending, take top-k
            candidates.sort(key=lambda c: c.confidence, reverse=True)
            results.append(candidates[: self.top_k])
        return results

    def _parse_raw_output(self, raw_out: Any, image_shape: Tuple[int, int]) -> List[BallCandidate]:
        candidates: List[BallCandidate] = []
        if raw_out is None:
            return candidates

        # Case 1: Heatmap array
        if isinstance(raw_out, np.ndarray) and raw_out.ndim == 2:
            return self._extract_peaks_from_heatmap(raw_out)

        # Case 2: List of candidates
        if isinstance(raw_out, (list, tuple)):
            for item in raw_out:
                if isinstance(item, dict):
                    x = float(item.get("x", item.get("cx", 0.0)))
                    y = float(item.get("y", item.get("cy", 0.0)))
                    conf = float(item.get("confidence", item.get("conf", item.get("score", 0.5))))
                    bbox = item.get("bbox", None)
                    if conf >= self.min_conf:
                        candidates.append(BallCandidate(x=x, y=y, confidence=conf, bbox=bbox))
                elif isinstance(item, (list, tuple, np.ndarray)) and len(item) >= 4:
                    # [x1, y1, x2, y2, (conf)]
                    x1, y1, x2, y2 = float(item[0]), float(item[1]), float(item[2]), float(item[3])
                    conf = float(item[4]) if len(item) > 4 else 0.5
                    cx = (x1 + x2) / 2.0
                    cy = (y1 + y2) / 2.0
                    if conf >= self.min_conf:
                        candidates.append(BallCandidate(x=cx, y=cy, confidence=conf, bbox=(x1, y1, x2, y2)))
        return candidates

    def _extract_peaks_from_heatmap(self, heatmap: np.ndarray) -> List[BallCandidate]:
        """Extract candidate peaks from a 2D confidence heatmap using dilation."""
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        dilated = cv2.dilate(heatmap, kernel)
        peaks = (heatmap == dilated) & (heatmap > self.min_conf)
        ys, xs = np.where(peaks)
        candidates = []
        for y, x in zip(ys, xs):
            candidates.append(BallCandidate(x=float(x), y=float(y), confidence=float(heatmap[y, x])))
        return candidates

    def _detect_fallback(self, frame: np.ndarray) -> List[BallCandidate]:
        """Classical circular Hough/blob detector fallback."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (9, 9), 2)
        circles = cv2.HoughCircles(
            blurred,
            cv2.HOUGH_GRADIENT,
            dp=1.2,
            minDist=20,
            param1=50,
            param2=25,
            minRadius=3,
            maxRadius=25,
        )
        candidates: List[BallCandidate] = []
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for c in circles[0, : self.top_k]:
                candidates.append(BallCandidate(x=float(c[0]), y=float(c[1]), confidence=0.5, radius=float(c[2])))
        return candidates


class OpenCVLinePitchFallback:
    """Classical computer vision fallback to detect pitch lines, creases, and stumps."""

    @staticmethod
    def detect_landmarks(frame: np.ndarray) -> PitchLandmarks:
        h, w = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Segment bright white pitch lines via adaptive/color thresholding
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # White lines: low saturation, high value
        white_mask = cv2.inRange(hsv, np.array([0, 0, 180]), np.array([180, 50, 255]))
        edges = cv2.Canny(white_mask, 50, 150)
        
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=40, minLineLength=30, maxLineGap=10)
        
        landmarks = PitchLandmarks(confidence=0.5)
        # If not enough lines, synthesize reasonable default pixel positions for camera view
        # Default typical broadcast view framing: pitch starts near bottom center and converges toward center-top
        landmarks.points_2d = {
            "striker_stump_base": (w * 0.50, h * 0.78),
            "striker_stump_top": (w * 0.50, h * 0.70),
            "striker_popping_center": (w * 0.50, h * 0.74),
            "striker_popping_return_off": (w * 0.62, h * 0.74),
            "striker_popping_return_leg": (w * 0.38, h * 0.74),
            "striker_bowling_return_off": (w * 0.60, h * 0.78),
            "striker_bowling_return_leg": (w * 0.40, h * 0.78),
            "bowler_stump_base": (w * 0.50, h * 0.32),
            "bowler_stump_top": (w * 0.50, h * 0.30),
            "bowler_popping_center": (w * 0.50, h * 0.34),
        }
        return landmarks


class GenericPitchDetectorAdapter(PitchDetector):
    """Adapter for custom pitch segmentation / keypoint detection models."""

    def __init__(
        self,
        detector_fn: Optional[Callable[[np.ndarray], Dict[str, Any]]] = None,
        use_fallback_if_incomplete: bool = True,
    ):
        self.detector_fn = detector_fn
        self.use_fallback_if_incomplete = use_fallback_if_incomplete
        self.fallback = OpenCVLinePitchFallback()

    def detect(self, frame: np.ndarray) -> PitchLandmarks:
        if self.detector_fn is None:
            return self.fallback.detect_landmarks(frame)

        raw = self.detector_fn(frame)
        landmarks = PitchLandmarks()

        # Parse keypoints dict
        if isinstance(raw, dict):
            pts_dict = raw.get("keypoints", raw.get("points_2d", {}))
            for k, v in pts_dict.items():
                if isinstance(v, (list, tuple)) and len(v) >= 2:
                    landmarks.points_2d[k] = (float(v[0]), float(v[1]))
            landmarks.pitch_polygon = raw.get("pitch_polygon", None)
            landmarks.pitch_mask = raw.get("pitch_mask", None)
            landmarks.confidence = float(raw.get("confidence", 0.9))

        # Check if essential stump and crease landmarks are present (at least 4 points)
        pts_3d, pts_2d = landmarks.get_correspondences()
        if len(pts_3d) < 4 and self.use_fallback_if_incomplete:
            logger.info("Pitch detector missing critical keypoints; executing OpenCV classical fallback.")
            fb = self.fallback.detect_landmarks(frame)
            # Fill missing keys
            for k, v in fb.points_2d.items():
                if k not in landmarks.points_2d:
                    landmarks.points_2d[k] = v
            landmarks.confidence = min(landmarks.confidence, 0.6)

        return landmarks


class SyntheticBallDetector(BallDetector):
    """Synthetic ball detector for tests and simulation."""

    def __init__(
        self,
        ground_truth_2d: List[Optional[Tuple[float, float]]],
        noise_sigma_px: float = 0.5,
        drop_rate: float = 0.15,
        num_false_positives: int = 2,
        image_shape: Tuple[int, int] = (1080, 1920),
        seed: Optional[int] = 42,
    ):
        self.ground_truth_2d = ground_truth_2d
        self.noise_sigma = noise_sigma_px
        self.drop_rate = drop_rate
        self.num_fp = num_false_positives
        self.h, self.w = image_shape
        self.rng = np.random.default_rng(seed)

    def detect(self, frames: List[np.ndarray]) -> List[List[BallCandidate]]:
        num_frames = len(frames)
        results: List[List[BallCandidate]] = []
        for i in range(num_frames):
            frame_cands: List[BallCandidate] = []
            gt = self.ground_truth_2d[i] if i < len(self.ground_truth_2d) else None
            
            # Determine if true detection is kept
            if gt is not None and self.rng.random() > self.drop_rate:
                noise_x = self.rng.normal(0, self.noise_sigma)
                noise_y = self.rng.normal(0, self.noise_sigma)
                x = float(np.clip(gt[0] + noise_x, 0, self.w - 1))
                y = float(np.clip(gt[1] + noise_y, 0, self.h - 1))
                conf = float(self.rng.uniform(0.75, 0.98))
                frame_cands.append(BallCandidate(x=x, y=y, confidence=conf, radius=5.0))

            # Add false positives
            for _ in range(self.num_fp):
                # Sample random false candidate in pitch corridor area
                fx = float(self.rng.uniform(self.w * 0.35, self.w * 0.65))
                fy = float(self.rng.uniform(self.h * 0.25, self.h * 0.85))
                fconf = float(self.rng.uniform(0.15, 0.45))
                frame_cands.append(BallCandidate(x=fx, y=fy, confidence=fconf, radius=4.0))

            results.append(frame_cands)
        return results


class SyntheticPitchDetector(PitchDetector):
    """Synthetic pitch detector projecting exact 3D landmarks via camera model."""

    def __init__(
        self,
        K: np.ndarray,
        R: np.ndarray,
        t: np.ndarray,
        noise_sigma_px: float = 0.5,
        seed: Optional[int] = 42,
    ):
        self.K = K
        self.R = R
        self.t = t.reshape(3, 1)
        self.noise_sigma = noise_sigma_px
        self.rng = np.random.default_rng(seed)

    def detect(self, frame: np.ndarray) -> PitchLandmarks:
        canon = PitchLandmarks.get_canonical_3d_coordinates()
        pts_2d: Dict[str, Tuple[float, float]] = {}

        for name, pt3 in canon.items():
            P = np.array(pt3, dtype=np.float64).reshape(3, 1)
            P_cam = self.R @ P + self.t
            if P_cam[2, 0] <= 0.1:
                continue
            p_img = self.K @ P_cam
            u = p_img[0, 0] / p_img[2, 0] + self.rng.normal(0, self.noise_sigma)
            v = p_img[1, 0] / p_img[2, 0] + self.rng.normal(0, self.noise_sigma)
            pts_2d[name] = (float(u), float(v))

        return PitchLandmarks(points_2d=pts_2d, confidence=0.98)
