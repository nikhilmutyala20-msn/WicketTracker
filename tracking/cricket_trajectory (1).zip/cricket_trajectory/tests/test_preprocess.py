"""Unit tests for video preprocessing: bob deinterlacing, duplicate frame detection, and overlay masking."""

import unittest
import numpy as np

from cricket_traj.preprocess import VideoPreprocessor


class TestPreprocess(unittest.TestCase):

    def setUp(self):
        self.preprocessor = VideoPreprocessor(
            deinterlace_bob=True,
            duplicate_mad_thresh=1.5,
            overlay_bottom_ratio=0.10,
            overlay_top_ratio=0.05,
        )

    def test_bob_deinterlace(self):
        # Create an artificial interlaced pattern
        h, w = 100, 100
        frame = np.zeros((h, w, 3), dtype=np.uint8)
        frame[0::2, :] = 200  # Even scanlines bright
        frame[1::2, :] = 50   # Odd scanlines dark

        deinterlaced = VideoPreprocessor.bob_deinterlace(frame)
        self.assertEqual(deinterlaced.shape, frame.shape)
        # Even scanlines should be interpolated from adjacent lines
        self.assertTrue(np.all(deinterlaced[1:-1:2, :] >= 50))

    def test_overlay_mask_computation(self):
        h, w = 1000, 1920
        # Bottom 10% = 100px, top 5% = 50px
        overlay_mask = np.ones((h, w), dtype=np.uint8)
        bottom_h = int(h * 0.10)
        top_h = int(h * 0.05)
        overlay_mask[h - bottom_h :, :] = 0
        overlay_mask[:top_h, :] = 0

        self.assertEqual(overlay_mask[0, 100], 0)       # Top masked
        self.assertEqual(overlay_mask[950, 100], 0)     # Bottom masked
        self.assertEqual(overlay_mask[500, 100], 1)     # Center active

    def test_duplicate_frame_mad(self):
        # Two identical frames should have zero MAD
        f1 = np.ones((100, 100), dtype=np.uint8) * 120
        f2 = np.ones((100, 100), dtype=np.uint8) * 120
        mad = float(np.mean(np.abs(f1.astype(float) - f2.astype(float))))
        self.assertAlmostEqual(mad, 0.0)

        # Perturbed frame
        f3 = f1.copy()
        f3[:10, :10] = 200
        mad_diff = float(np.mean(np.abs(f1.astype(float) - f3.astype(float))))
        self.assertGreater(mad_diff, 0.0)


if __name__ == "__main__":
    unittest.main()
