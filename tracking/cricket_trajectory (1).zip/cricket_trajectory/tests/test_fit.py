"""Unit tests for trajectory fitting, parameter optimization, and covariance propagation."""

import unittest
import numpy as np

from cricket_traj.calibration import CameraPose
from cricket_traj.config import DEFAULT_CONFIG
from cricket_traj.events import DeliveryEvents
from cricket_traj.fit import TrajectoryFitter
from cricket_traj.physics import BallPhysics, PhysicsParams
from cricket_traj.tracking import TrackPoint


class TestFit(unittest.TestCase):

    def setUp(self):
        self.cfg = DEFAULT_CONFIG
        self.fitter = TrajectoryFitter(self.cfg)
        self.physics = BallPhysics(self.cfg)

        f = 2200.0
        w, h = 1920, 1080
        K = np.array([[f, 0, w / 2.0], [0, f, h / 2.0], [0, 0, 1.0]])
        C = np.array([25.0, 0.5, 4.0])
        target = np.array([10.0, 0.0, 0.5])
        up = np.array([0.0, 0.0, 1.0])
        fwd = (target - C) / np.linalg.norm(target - C)
        right = np.cross(fwd, up)
        right /= np.linalg.norm(right)
        cam_up = np.cross(right, fwd)
        R = np.vstack([right, -cam_up, fwd])
        t = -R @ C.reshape(3, 1)
        self.pose = CameraPose(K=K, R=R, t=t, focal_length=f, is_valid=True)

    def test_trajectory_fitter_recovers_known_parameters(self):
        p0 = np.array([20.0, 0.05, 2.15])
        v0 = np.array([-36.0, -0.2, -1.8])
        params_pre = PhysicsParams(k_drag=self.physics.default_k, swing_accel=0.2)

        tb, pb, vb = self.physics.find_pitch_bounce(p0, v0, 0.0, params_pre)
        params_post = PhysicsParams(
            k_drag=self.physics.default_k,
            swing_accel=0.2,
            restitution_e=0.62,
            friction_x=0.20,
            friction_y=0.15,
            seam_lateral_kick=-0.4,
        )
        vb_after = self.physics.apply_bounce_collision(vb, params_post)

        num_pts = 20
        ts = np.linspace(0.0, 0.50, num_pts)
        track = []
        poses = [self.pose] * num_pts

        for i, t in enumerate(ts):
            if t <= tb:
                _, p, _ = self.physics.integrate_flight(np.concatenate([p0, v0]), (0.0, t), params_pre)
            else:
                _, p, _ = self.physics.integrate_flight(np.concatenate([pb, vb_after]), (tb, t), params_post)
            pos3 = p[-1]
            uv = self.pose.project(pos3.reshape(1, 3))[0]
            track.append(
                TrackPoint(
                    frame_idx=i,
                    timestamp=float(t),
                    x=float(uv[0]),
                    y=float(uv[1]),
                    confidence=0.95,
                    is_observed=True,
                )
            )

        events = DeliveryEvents(
            release_frame=0,
            release_time=0.0,
            bounce_frame=int(np.argmin(np.abs(ts - tb))),
            bounce_time=float(tb),
            bounce_is_observed=True,
            impact_frame=num_pts - 1,
            impact_time=float(ts[-1]),
        )

        fit_res = self.fitter.fit(track, poses, events, speed_gun_kmh=130.0)

        self.assertTrue(fit_res.is_converged)
        np.testing.assert_allclose(fit_res.p_bounce[:2], pb[:2], atol=0.10)
        self.assertEqual(fit_res.stump_plane_cov.shape, (2, 2))
        self.assertTrue(np.all(np.linalg.eigvals(fit_res.stump_plane_cov) > 0))


if __name__ == "__main__":
    unittest.main()
