"""Unit tests for Hawk-Eye LBW classifier edge cases, boundary thresholds, and handedness rules."""

import unittest
import numpy as np

from cricket_traj.config import Config
from cricket_traj.fit import TrajectoryFitResult
from cricket_traj.lbw import LBWClassifier, PitchingVerdict, ImpactVerdict, WicketsVerdict


class TestLBW(unittest.TestCase):

    def setUp(self):
        self.cfg_rhb = Config()
        self.cfg_rhb.lbw.handedness = "right"
        self.classifier_rhb = LBWClassifier(self.cfg_rhb)

        self.cfg_lhb = Config()
        self.cfg_lhb.lbw.handedness = "left"
        self.classifier_lhb = LBWClassifier(self.cfg_lhb)

    def _create_mock_fit_res(self, y_bounce: float, y_stump: float, z_stump: float) -> TrajectoryFitResult:
        cov = np.diag([0.02**2, 0.02**2])
        dense_x = np.linspace(20.0, 0.0, 50)
        dense_y = np.linspace(y_bounce, y_stump, 50)
        dense_z = np.linspace(1.5, z_stump, 50)
        traj_3d = np.column_stack([dense_x, dense_y, dense_z])

        return TrajectoryFitResult(
            p_release=np.array([20.0, 0.0, 2.1]),
            v_release=np.array([-35.0, 0.0, -1.5]),
            speed_release_kmh=126.0,
            bounce_time=0.3,
            p_bounce=np.array([7.0, y_bounce, 0.036]),
            v_bounce_before=np.array([-30.0, 0.0, -4.0]),
            v_bounce_after=np.array([-25.0, 0.0, 2.5]),
            k_drag=0.0034,
            swing_accel=0.0,
            restitution_e=0.6,
            friction_x=0.2,
            seam_lateral_kick=0.0,
            t_stump=0.55,
            p_stump=np.array([0.0, y_stump, z_stump]),
            v_stump=np.array([-24.0, 0.0, 1.2]),
            stump_plane_cov=cov,
            timestamps=np.linspace(0.0, 0.55, 50),
            trajectory_3d=traj_3d,
            param_covariance=np.eye(12) * 0.01,
            mean_reprojection_error_px=0.5,
        )

    def test_pitching_outside_leg_rhb_is_not_out(self):
        fit_res = self._create_mock_fit_res(y_bounce=-0.15, y_stump=0.0, z_stump=0.40)
        decision = self.classifier_rhb.evaluate(fit_res, impact_point=np.array([1.2, 0.0, 0.4]))

        self.assertEqual(decision.pitching_verdict, PitchingVerdict.OUTSIDE_LEG)
        self.assertIn("NOT OUT", decision.overall_decision)
        self.assertIn("Pitched Outside Leg", decision.overall_decision)

    def test_pitching_outside_leg_lhb(self):
        fit_res = self._create_mock_fit_res(y_bounce=0.15, y_stump=0.0, z_stump=0.40)
        decision = self.classifier_lhb.evaluate(fit_res, impact_point=np.array([1.2, 0.0, 0.4]))

        self.assertEqual(decision.pitching_verdict, PitchingVerdict.OUTSIDE_LEG)
        self.assertIn("NOT OUT", decision.overall_decision)

    def test_pitching_in_line_rhb(self):
        fit_res = self._create_mock_fit_res(y_bounce=0.05, y_stump=0.0, z_stump=0.40)
        decision = self.classifier_rhb.evaluate(fit_res, impact_point=np.array([1.2, 0.0, 0.4]))

        self.assertEqual(decision.pitching_verdict, PitchingVerdict.IN_LINE)
        self.assertEqual(decision.impact_verdict, ImpactVerdict.IN_LINE)
        self.assertEqual(decision.wickets_verdict, WicketsVerdict.HITTING)
        self.assertEqual(decision.overall_decision, "OUT (LBW)")

    def test_wickets_missing_over_stumps(self):
        fit_res = self._create_mock_fit_res(y_bounce=0.0, y_stump=0.0, z_stump=0.95)
        decision = self.classifier_rhb.evaluate(fit_res, impact_point=np.array([1.2, 0.0, 0.4]))

        self.assertEqual(decision.pitching_verdict, PitchingVerdict.IN_LINE)
        self.assertEqual(decision.wickets_verdict, WicketsVerdict.MISSING)
        self.assertEqual(decision.overall_decision, "NOT OUT (Wickets Missing)")

    def test_wickets_umpires_call_clipping_bail(self):
        fit_res = self._create_mock_fit_res(y_bounce=0.0, y_stump=0.0, z_stump=0.730)
        decision = self.classifier_rhb.evaluate(fit_res, impact_point=np.array([1.2, 0.0, 0.4]))

        self.assertEqual(decision.wickets_verdict, WicketsVerdict.UMPIRES_CALL)
        self.assertEqual(decision.overall_decision, "UMPIRE'S CALL")

    def test_probability_mass_calculation(self):
        prob = self.classifier_rhb._compute_probability_mass(
            mu=[0.0, 0.35],
            cov=np.diag([0.02**2, 0.02**2]),
            y_bounds=(-0.1503, 0.1503),
            z_bounds=(0.0, 0.747),
        )
        self.assertGreater(prob, 0.95)


if __name__ == "__main__":
    unittest.main()
