"""End-to-end integration test running synthetic delivery through full Hawk-Eye pipeline."""

import json
from pathlib import Path
import tempfile
import unittest
import numpy as np

from cricket_traj.adapters import SyntheticBallDetector, SyntheticPitchDetector
from cricket_traj.cli import run_pipeline
from cricket_traj.config import DEFAULT_CONFIG
from cricket_traj.interfaces import PitchLandmarks
from examples.synthetic_delivery_generator import SyntheticDeliverySimulator


class SequencePitchDetector:
    """Provides camera-projected pitch landmarks for each frame of a sequence."""

    def __init__(self, poses):
        self.poses = poses
        self.call_idx = 0

    def detect(self, frame):
        pose = self.poses[min(self.call_idx, len(self.poses) - 1)]
        self.call_idx += 1
        canon = PitchLandmarks.get_canonical_3d_coordinates()
        pts_2d = {}
        for name, pt3 in canon.items():
            p2 = pose.project(np.array(pt3).reshape(1, 3))[0]
            pts_2d[name] = (float(p2[0]), float(p2[1]))
        return PitchLandmarks(points_2d=pts_2d, confidence=0.98)


class TestSyntheticPipeline(unittest.TestCase):

    def test_full_pipeline_synthetic_execution(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            out_dir = Path(tmp_dir) / "output"
            video_path = out_dir / "test_clip.mp4"

            sim = SyntheticDeliverySimulator(DEFAULT_CONFIG, seed=42)
            sim_data = sim.simulate_delivery(
                speed_kmh=134.0,
                release_pos=(20.0, 0.10, 2.15),
                swing_accel=0.30,
                seam_kick=-0.50,
            )

            poses = sim.simulate_moving_camera_sequence(len(sim_data["timestamps"]))
            sim.render_synthetic_video_clip(sim_data, poses, video_path)

            gt_2d = [poses[i].project(p.reshape(1, 3))[0] for i, p in enumerate(sim_data["positions_3d"])]
            ball_det = SyntheticBallDetector(
                ground_truth_2d=[(float(p[0]), float(p[1])) for p in gt_2d],
                noise_sigma_px=0.5,
                drop_rate=0.10,
                num_false_positives=1,
            )
            pitch_det = SequencePitchDetector(poses)

            res = run_pipeline(
                video_path=video_path,
                out_dir=out_dir,
                fps=50.0,
                handedness="right",
                speed_kmh=134.0,
                ball_detector=ball_det,
                pitch_detector=pitch_det,
            )

            self.assertEqual(res["status"], "SUCCESS")
            self.assertTrue(Path(res["overlay_video"]).exists())
            self.assertTrue(Path(res["virtual_video"]).exists())
            self.assertTrue(Path(res["pitch_map"]).exists())
            self.assertTrue(Path(res["result_json"]).exists())

            with open(res["result_json"], "r") as f:
                data = json.load(f)

            self.assertEqual(data["status"], "SUCCESS")
            est_bounce_x = data["pitching"]["x_m"]
            gt_bounce_x = sim_data["p_bounce"][0]
            self.assertLess(abs(est_bounce_x - gt_bounce_x), 0.10)

            est_stump_y = data["wickets"]["predicted_y_m"]
            gt_stump_y = sim_data["p_stump"][1]
            self.assertLess(abs(est_stump_y - gt_stump_y), 0.15)


if __name__ == "__main__":
    unittest.main()
