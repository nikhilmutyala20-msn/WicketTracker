"""Unit tests for event detection: release, bounce with sub-frame interpolation, and pad impact."""

import unittest
import numpy as np

from cricket_traj.events import EventDetector
from cricket_traj.tracking import TrackPoint


class TestEvents(unittest.TestCase):

    def setUp(self):
        self.detector = EventDetector()

    def test_subframe_bounce_interpolation(self):
        ts = np.linspace(0.0, 0.40, 21)
        tb_true = 0.205
        ys = []
        for t in ts:
            if t <= tb_true:
                ys.append(100.0 + 500.0 * t)
            else:
                ys.append(100.0 + 500.0 * tb_true - 300.0 * (t - tb_true))
        ys = np.array(ys)

        tb_est = self.detector._estimate_subframe_bounce_time(ts, ys, b_idx=10)
        self.assertAlmostEqual(tb_est, tb_true, delta=0.01)

    def test_detect_events_pipeline(self):
        num_frames = 25
        ts = np.linspace(0.0, 0.50, num_frames)
        track = []
        for i, t in enumerate(ts):
            x = 960.0
            y = 300.0 + 400.0 * t if t < 0.25 else 400.0 - 200.0 * (t - 0.25)
            track.append(
                TrackPoint(
                    frame_idx=i,
                    timestamp=float(t),
                    x=x,
                    y=y,
                    confidence=0.9,
                    is_observed=True,
                )
            )

        events = self.detector.detect_events(track, camera_poses=[])
        self.assertGreaterEqual(events.release_frame, 0)
        self.assertGreater(events.bounce_frame, events.release_frame)
        self.assertGreaterEqual(events.impact_frame, events.bounce_frame)


if __name__ == "__main__":
    unittest.main()
