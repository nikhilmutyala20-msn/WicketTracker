"""Unit test suite for cricket trajectory package."""
