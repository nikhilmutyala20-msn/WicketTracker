"""Unit tests for camera calibration, homography decomposition, PnP, and ray projection."""

import unittest
import numpy as np

from cricket_traj.calibration import CameraPose, PitchCalibrator
from cricket_traj.interfaces import PitchLandmarks


class TestCalibration(unittest.TestCase):

    def setUp(self):
        self.calibrator = PitchCalibrator()
        # Create known ground truth camera
        w, h = 1920, 1080
        f = 2500.0
        self.K_gt = np.array([[f, 0, w / 2.0], [0, f, h / 2.0], [0, 0, 1.0]], dtype=np.float64)
        # Camera at (25.0, 0.5, 4.0) looking towards (10.0, 0.0, 0.5)
        C = np.array([25.0, 0.5, 4.0], dtype=np.float64)
        target = np.array([10.0, 0.0, 0.5], dtype=np.float64)
        up = np.array([0.0, 0.0, 1.0])

        fwd = (target - C) / np.linalg.norm(target - C)
        right = np.cross(fwd, up)
        right /= np.linalg.norm(right)
        cam_up = np.cross(right, fwd)

        self.R_gt = np.vstack([right, -cam_up, fwd])
        self.t_gt = -self.R_gt @ C.reshape(3, 1)
        self.pose_gt = CameraPose(K=self.K_gt, R=self.R_gt, t=self.t_gt, focal_length=f)

    def test_camera_center_and_ray(self):
        C = self.pose_gt.camera_center
        # Verify optical center matches ground truth C = [25.0, 0.5, 4.0]
        np.testing.assert_allclose(C, [25.0, 0.5, 4.0], atol=1e-5)

        # Ray through principal point should align with optical axis (forward vector)
        w, h = 1920, 1080
        _, d = self.pose_gt.ray(w / 2.0, h / 2.0)
        # Forward vector in world is row 2 of R
        fwd_world = self.R_gt[2, :]
        np.testing.assert_allclose(d, fwd_world, atol=1e-5)

    def test_project_and_reprojection_error(self):
        # 3D points on pitch
        pts_3d = np.array([
            [0.0, 0.0, 0.0],
            [1.22, 0.0, 0.0],
            [20.12, 0.0, 0.0],
            [0.0, 0.0, 0.711],  # Stump top
        ])
        pts_2d = self.pose_gt.project(pts_3d)
        self.assertEqual(pts_2d.shape, (4, 2))

        # Check all points project inside or near frame
        self.assertTrue(np.all(pts_2d[:, 0] > 0))
        self.assertTrue(np.all(pts_2d[:, 1] > 0))

    def test_pnp_calibration_from_landmarks(self):
        # Project canonical landmarks to 2D
        canon = PitchLandmarks.get_canonical_3d_coordinates()
        landmarks = PitchLandmarks()
        for name, pt3 in canon.items():
            p2 = self.pose_gt.project(np.array(pt3).reshape(1, 3))[0]
            landmarks.points_2d[name] = (float(p2[0]), float(p2[1]))

        # Calibrate
        estimated_pose = self.calibrator.calibrate_from_landmarks(
            landmarks, (1080, 1920), prior_focal_length=2500.0
        )

        self.assertTrue(estimated_pose.is_valid)
        self.assertLess(estimated_pose.reprojection_error, 1.0)
        # Check camera center error < 10 cm
        np.testing.assert_allclose(estimated_pose.camera_center, self.pose_gt.camera_center, atol=0.10)


if __name__ == "__main__":
    unittest.main()
