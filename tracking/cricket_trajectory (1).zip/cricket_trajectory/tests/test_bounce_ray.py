"""Unit tests for bounce prediction, ray-plane intersection, and covariance estimation."""

import unittest
import numpy as np

from cricket_traj.bounce import BouncePredictor
from cricket_traj.calibration import CameraPose
from cricket_traj.config import DEFAULT_CONFIG


class TestBounceRay(unittest.TestCase):

    def setUp(self):
        self.cfg = DEFAULT_CONFIG
        self.predictor = BouncePredictor(self.cfg)

        # Setup standard camera
        f = 2000.0
        w, h = 1920, 1080
        K = np.array([[f, 0, w / 2.0], [0, f, h / 2.0], [0, 0, 1.0]], dtype=np.float64)
        C = np.array([25.0, 0.5, 4.0])
        target = np.array([7.0, 0.0, 0.0])
        up = np.array([0.0, 0.0, 1.0])

        fwd = (target - C) / np.linalg.norm(target - C)
        right = np.cross(fwd, up)
        right /= np.linalg.norm(right)
        cam_up = np.cross(right, fwd)

        R = np.vstack([right, -cam_up, fwd])
        t = -R @ C.reshape(3, 1)
        self.pose = CameraPose(K=K, R=R, t=t, focal_length=f)

    def test_ray_plane_intersection_exact_recovery(self):
        # Known ground truth bounce point on pitch
        r_ball = self.cfg.ball.radius
        true_bounce_3d = np.array([[7.25, 0.05, r_ball]])
        uv = self.pose.project(true_bounce_3d)[0]

        # Predict bounce from projected pixel
        pitching_pt = self.predictor.predict_observed_bounce(
            bounce_pixel=(uv[0], uv[1]),
            camera_pose=self.pose,
            timestamp=0.35,
            pixel_noise_sigma=0.5,
        )

        self.assertTrue(pitching_pt.is_observed)
        self.assertAlmostEqual(pitching_pt.x, 7.25, places=3)
        self.assertAlmostEqual(pitching_pt.y, 0.05, places=3)
        self.assertAlmostEqual(pitching_pt.z, r_ball, places=4)

        # Covariance must be positive definite
        cov = pitching_pt.covariance
        self.assertEqual(cov.shape, (2, 2))
        eigvals = np.linalg.eigvals(cov)
        self.assertTrue(np.all(eigvals > 0))

    def test_parallel_ray_fallback(self):
        # Camera ray parallel to ground: C_z = r_ball, ray d_z = 0
        K = np.eye(3) * 1000.0
        K[2, 2] = 1.0
        R = np.eye(3)
        t = np.zeros((3, 1))
        pose = CameraPose(K=K, R=R, t=t)

        pt = self.predictor.predict_observed_bounce(
            bounce_pixel=(500.0, 500.0),
            camera_pose=pose,
            timestamp=0.2,
        )
        self.assertIsNotNone(pt)


if __name__ == "__main__":
    unittest.main()
