"""Unit tests for 3D cricket ball physics, RK4 integration, drag, gravity, and bounce collisions."""

import unittest
import numpy as np

from cricket_traj.config import DEFAULT_CONFIG
from cricket_traj.physics import BallPhysics, PhysicsParams


class TestPhysics(unittest.TestCase):

    def setUp(self):
        self.physics = BallPhysics(DEFAULT_CONFIG)

    def test_drag_reduces_speed(self):
        # Ball released horizontally with high speed
        p0 = np.array([20.0, 0.0, 2.0])
        v0 = np.array([-40.0, 0.0, 0.0])  # 144 km/h
        params = PhysicsParams(k_drag=self.physics.default_k, swing_accel=0.0)

        ts, pos, vel = self.physics.integrate_flight(
            initial_state=np.concatenate([p0, v0]),
            t_span=(0.0, 0.4),
            params=params,
        )

        speed_start = np.linalg.norm(vel[0])
        speed_end = np.linalg.norm(vel[-1])

        # Drag must strictly dissipate kinetic energy and reduce speed
        self.assertLess(speed_end, speed_start)
        # Along-pitch velocity magnitude must decrease
        self.assertLess(abs(vel[-1, 0]), abs(vel[0, 0]))

    def test_gravity_accelerates_downward(self):
        # Drop ball from rest in vacuum (k=0)
        p0 = np.array([0.0, 0.0, 10.0])
        v0 = np.array([0.0, 0.0, 0.0])
        params = PhysicsParams(k_drag=0.0, swing_accel=0.0, gravity=9.81)

        t_fall = 0.5
        ts, pos, vel = self.physics.integrate_flight(
            initial_state=np.concatenate([p0, v0]),
            t_span=(0.0, t_fall),
            params=params,
        )

        # Expected: Z = Z0 - 0.5 * g * t^2
        expected_z = 10.0 - 0.5 * 9.81 * (t_fall**2)
        expected_vz = -9.81 * t_fall

        self.assertAlmostEqual(pos[-1, 2], expected_z, places=3)
        self.assertAlmostEqual(vel[-1, 2], expected_vz, places=3)

    def test_bounce_collision_restitution_and_friction(self):
        v_before = np.array([-30.0, 0.5, -4.0])
        e = 0.65
        mu_x = 0.20
        seam_kick = -0.50

        params = PhysicsParams(
            restitution_e=e,
            friction_x=mu_x,
            friction_y=0.15,
            seam_lateral_kick=seam_kick,
        )

        v_after = self.physics.apply_bounce_collision(v_before, params)

        # 1. Normal velocity must reverse and scale by e
        self.assertAlmostEqual(v_after[2], -e * v_before[2], places=5)
        self.assertGreater(v_after[2], 0.0)  # Rebounding upward

        # 2. Tangential velocity along X must scale by (1 - mu_x)
        self.assertAlmostEqual(v_after[0], (1.0 - mu_x) * v_before[0], places=5)

        # 3. Lateral velocity must reflect seam kick
        expected_vy = (1.0 - 0.15) * v_before[1] + seam_kick
        self.assertAlmostEqual(v_after[1], expected_vy, places=5)


if __name__ == "__main__":
    unittest.main()
