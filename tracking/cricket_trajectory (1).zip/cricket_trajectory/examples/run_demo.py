"""Run a full demonstration of the Hawk-Eye Cricket Trajectory pipeline on synthetic data."""

from pathlib import Path
from examples.synthetic_delivery_generator import generate_synthetic_demo, run_synthetic_benchmark

if __name__ == "__main__":
    demo_out = Path("examples/sample_outputs")
    demo_out.mkdir(parents=True, exist_ok=True)
    print("Step 1: Generating synthetic cricket delivery and running Hawk-Eye pipeline...")
    generate_synthetic_demo(out_dir=demo_out)
    print("\nStep 2: Running Monte Carlo acceptance benchmark (50 runs)...")
    run_synthetic_benchmark(num_runs=50)
