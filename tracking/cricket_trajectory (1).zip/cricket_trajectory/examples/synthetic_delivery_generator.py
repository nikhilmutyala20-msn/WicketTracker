from cricket_traj.tracking import BallTracker
from cricket_traj.bounce import BouncePredictor
"""Synthetic cricket delivery video generator and Monte Carlo acceptance benchmark."""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import cv2
import numpy as np

from cricket_traj.adapters import SyntheticBallDetector, SyntheticPitchDetector
from cricket_traj.calibration import CameraPose, PitchCalibrator
from cricket_traj.cli import run_pipeline
from cricket_traj.config import Config, DEFAULT_CONFIG
from cricket_traj.events import EventDetector
from cricket_traj.fit import TrajectoryFitter
from cricket_traj.interfaces import BallCandidate, PitchLandmarks
from cricket_traj.lbw import LBWClassifier
from cricket_traj.physics import BallPhysics, PhysicsParams

logger = logging.getLogger(__name__)


class SyntheticDeliverySimulator:
    """Simulates realistic 3D cricket delivery, moving broadcast PTZ camera, and noisy detections."""

    def __init__(self, config: Optional[Config] = None, seed: Optional[int] = 42):
        self.cfg = config or DEFAULT_CONFIG
        self.physics = BallPhysics(self.cfg)
        self.rng = np.random.default_rng(seed)

    def simulate_delivery(
        self,
        speed_kmh: float = 135.0,
        release_pos: Tuple[float, float, float] = (20.0, 0.12, 2.18),
        swing_accel: float = 0.45,
        seam_kick: float = -0.65,
        fps: float = 50.0,
    ) -> Dict:
        """Simulates ground truth 3D physics trajectory of a cricket delivery."""
        vx0 = -(speed_kmh / 3.6) * 0.98
        vy0 = -0.35
        vz0 = -2.2
        p0 = np.array(release_pos, dtype=np.float64)
        v0 = np.array([vx0, vy0, vz0], dtype=np.float64)

        params_pre = PhysicsParams(
            k_drag=self.physics.default_k,
            swing_accel=swing_accel,
        )

        # 1. Pre-bounce flight to pitch collision
        tb, pb, vb_before = self.physics.find_pitch_bounce(p0, v0, 0.0, params_pre)

        # 2. Bounce collision
        params_post = PhysicsParams(
            k_drag=self.physics.default_k,
            swing_accel=swing_accel,
            restitution_e=0.62,
            friction_x=0.20,
            friction_y=0.15,
            seam_lateral_kick=seam_kick,
        )
        vb_after = self.physics.apply_bounce_collision(vb_before, params_post)

        # 3. Post-bounce flight to stump plane (X = 0)
        t_stump, p_stump, v_stump, _, _ = self.physics.integrate_to_stump_plane(
            p_start=pb,
            v_start=vb_after,
            t_start=tb,
            params=params_post,
            target_x=0.0,
        )

        # Discretize into per-frame timestamps
        total_time = t_stump + 0.05
        frame_times = np.arange(0.0, total_time, 1.0 / fps)
        num_frames = len(frame_times)

        pos_3d = np.zeros((num_frames, 3))
        vel_3d = np.zeros((num_frames, 3))

        for i, t in enumerate(frame_times):
            if t <= tb:
                _, p, v = self.physics.integrate_flight(
                    np.concatenate([p0, v0]), (0.0, t), params_pre
                )
                pos_3d[i] = p[-1]
                vel_3d[i] = v[-1]
            else:
                _, p, v = self.physics.integrate_flight(
                    np.concatenate([pb, vb_after]), (tb, t), params_post
                )
                pos_3d[i] = p[-1]
                vel_3d[i] = v[-1]

        # Impact frame: near popping crease (X ~ 1.22 m)
        impact_idx = int(np.argmin(np.abs(pos_3d[:, 0] - 1.22)))

        return {
            "timestamps": frame_times,
            "positions_3d": pos_3d,
            "velocities_3d": vel_3d,
            "t_bounce": tb,
            "p_bounce": pb,
            "v_bounce_before": vb_before,
            "v_bounce_after": vb_after,
            "t_stump": t_stump,
            "p_stump": p_stump,
            "impact_idx": impact_idx,
            "impact_pos": pos_3d[impact_idx],
            "speed_kmh": speed_kmh,
            "swing_accel": swing_accel,
            "seam_kick": seam_kick,
        }

    def simulate_moving_camera_sequence(
        self,
        num_frames: int,
        image_shape: Tuple[int, int] = (1080, 1920),
    ) -> List[CameraPose]:
        """Simulates camera tracking bowler-to-striker with subtle pan, tilt, and zoom."""
        h, w = image_shape
        poses: List[CameraPose] = []

        # Camera starts high behind bowler: X = 25.0, Y = 0.5, Z = 4.2
        # Slight pan/zoom as ball approaches batter
        for i in range(num_frames):
            frac = i / max(num_frames - 1, 1)
            cx = 25.0 - 0.8 * frac
            cy = 0.5 + 0.2 * frac
            cz = 4.2 - 0.3 * frac
            C_cam = np.array([cx, cy, cz])

            # Target point tracks ball down the pitch
            target = np.array([10.0 - 8.0 * frac, 0.0, 0.8])
            up = np.array([0.0, 0.0, 1.0])

            fwd = (target - C_cam) / np.linalg.norm(target - C_cam)
            right = np.cross(fwd, up)
            right /= np.linalg.norm(right)
            cam_up = np.cross(right, fwd)

            R = np.vstack([right, -cam_up, fwd])
            t = -R @ C_cam.reshape(3, 1)
            # Zoom lens: focal length increases slightly as camera tracks delivery
            f = 2200.0 + 150.0 * frac
            K = np.array([[f, 0, w / 2.0], [0, f, h / 2.0], [0, 0, 1.0]])

            poses.append(CameraPose(K=K, R=R, t=t, focal_length=f, is_valid=True))

        return poses

    def render_synthetic_video_clip(
        self,
        sim_data: Dict,
        camera_poses: List[CameraPose],
        out_video_path: str | Path,
        image_shape: Tuple[int, int] = (1080, 1920),
        fps: float = 50.0,
    ) -> Path:
        """Renders synthetic cricket broadcast delivery video with pitch markings and ball."""
        out_video_path = Path(out_video_path)
        out_video_path.parent.mkdir(parents=True, exist_ok=True)
        h, w = image_shape

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(out_video_path), fourcc, fps, (w, h))

        pos_3d = sim_data["positions_3d"]
        num_frames = len(camera_poses)
        w_stump = self.cfg.lbw.stump_half_width
        pitch_len = self.cfg.pitch.length_between_stumps
        pitch_w = self.cfg.pitch.width

        for i in range(num_frames):
            pose = camera_poses[i]
            frame = np.zeros((h, w, 3), dtype=np.uint8)
            # Grass green background
            frame[:] = (40, 95, 35)

            # Draw pitch strip
            pitch_corners = np.array([
                [-1.0, -pitch_w / 2.0, 0.0],
                [-1.0, pitch_w / 2.0, 0.0],
                [pitch_len + 1.0, pitch_w / 2.0, 0.0],
                [pitch_len + 1.0, -pitch_w / 2.0, 0.0],
            ])
            p_pitch = pose.project(pitch_corners).astype(np.int32)
            cv2.fillPoly(frame, [p_pitch], (145, 185, 210))  # Tan pitch

            # Draw popping crease lines
            pop_striker = np.array([[1.22, -1.8, 0.0], [1.22, 1.8, 0.0]])
            p_pop = pose.project(pop_striker).astype(np.int32)
            cv2.line(frame, tuple(p_pop[0]), tuple(p_pop[1]), (255, 255, 255), 3, cv2.LINE_AA)

            pop_bowler = np.array([[pitch_len - 1.22, -1.8, 0.0], [pitch_len - 1.22, 1.8, 0.0]])
            p_pop_b = pose.project(pop_bowler).astype(np.int32)
            cv2.line(frame, tuple(p_pop_b[0]), tuple(p_pop_b[1]), (255, 255, 255), 2, cv2.LINE_AA)

            # Draw stumps (striker)
            for y_s in [-w_stump, 0.0, w_stump]:
                s_base = pose.project(np.array([[0.0, y_s, 0.0]]))[0].astype(np.int32)
                s_top = pose.project(np.array([[0.0, y_s, 0.711]]))[0].astype(np.int32)
                cv2.line(frame, tuple(s_base), tuple(s_top), (230, 245, 255), 4, cv2.LINE_AA)

            # Draw cricket ball
            if i < len(pos_3d):
                b_pt_3d = pos_3d[i]
                b_proj = pose.project(b_pt_3d.reshape(1, 3))[0].astype(np.int32)
                z_cam = (pose.R @ b_pt_3d.reshape(3, 1) + pose.t)[2, 0]
                r_px = max(3, int(pose.focal_length * self.cfg.ball.radius / max(z_cam, 1.0)))
                cv2.circle(frame, tuple(b_proj), r_px, (20, 25, 200), -1, cv2.LINE_AA)

            # Broadcast score overlay bar at bottom
            overlay_h = int(h * 0.10)
            cv2.rectangle(frame, (0, h - overlay_h), (w, h), (20, 20, 20), -1)
            cv2.putText(frame, "LIVE BROADCAST - 1ST TEST MATCH", (40, h - 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA)

            writer.write(frame)

        writer.release()
        return out_video_path


def run_synthetic_benchmark(num_runs: int = 200, seed: int = 100):
    """Executes Monte Carlo benchmark verifying recovery accuracy on synthetic deliveries.
    
    Acceptance criteria:
      - Recover bounce point within 10 cm (< 0.10 m)
      - Recover stump-plane prediction within 15 cm (< 0.15 m)
      - 1-sigma uncertainty covers truth in ~68% of runs
    """
    print(f"\n========================================================")
    print(f"RUNNING MONTE CARLO ACCEPTANCE BENCHMARK ({num_runs} RUNS)")
    print(f"========================================================\n")

    cfg = DEFAULT_CONFIG
    sim = SyntheticDeliverySimulator(cfg, seed=seed)
    rng = np.random.default_rng(seed)

    bounce_errors_m = []
    stump_errors_m = []
    stump_covered_1sigma = 0

    for run_idx in range(num_runs):
        # Vary physical parameters across realistic delivery distributions
        speed_kmh = float(rng.uniform(120.0, 145.0))
        swing = float(rng.uniform(-0.6, 0.6))
        seam = float(rng.uniform(-0.8, 0.8))
        rel_y = float(rng.uniform(-0.25, 0.25))

        sim_data = sim.simulate_delivery(
            speed_kmh=speed_kmh,
            release_pos=(20.0, rel_y, 2.15),
            swing_accel=swing,
            seam_kick=seam,
        )

        poses = sim.simulate_moving_camera_sequence(len(sim_data["timestamps"]))

        # Project ground-truth ball to 2D
        gt_2d = []
        for i, pos in enumerate(sim_data["positions_3d"]):
            p2 = poses[i].project(pos.reshape(1, 3))[0]
            gt_2d.append((float(p2[0]), float(p2[1])))

        # Add 0.8px pixel noise, 15% drop rate, and false candidates
        detector = SyntheticBallDetector(
            ground_truth_2d=gt_2d,
            noise_sigma_px=0.8,
            drop_rate=0.15,
            num_false_positives=2,
            seed=seed + run_idx,
        )

        # Track ball
        candidates_list = detector.detect([None] * len(poses))
        tracker = BallTracker(cfg)
        track_points = tracker.track(candidates_list, poses, sim_data["timestamps"], (1080, 1920))

        # Events
        event_detector = EventDetector()
        events = event_detector.detect_events(track_points, poses)

        # Pitching point
        b_pt = track_points[events.bounce_frame]
        bx = b_pt.raw_x if b_pt.raw_x is not None else b_pt.x
        by = b_pt.raw_y if b_pt.raw_y is not None else b_pt.y
        pitching_pt = BouncePredictor(cfg).predict_observed_bounce((bx, by), poses[events.bounce_frame], events.bounce_time)

        # Fit joint physics trajectory
        fitter = TrajectoryFitter(cfg)
        fit_res = fitter.fit(track_points, poses, events, speed_gun_kmh=speed_kmh, pitching_point=pitching_pt)

        # 1. Bounce point error: Euclidean distance between fitted p_bounce and ground truth
        pb_gt = sim_data["p_bounce"][:2]
        pb_est = np.array([pitching_pt.x, pitching_pt.y])
        err_bounce = float(np.linalg.norm(pb_est - pb_gt))
        bounce_errors_m.append(err_bounce)

        # 2. Stump plane error: Euclidean distance between fitted p_stump and ground truth at X = 0
        pstump_gt = sim_data["p_stump"][1:3]
        pstump_est = fit_res.p_stump[1:3]
        err_stump = float(np.linalg.norm(pstump_est - pstump_gt))
        stump_errors_m.append(err_stump)

        # 3. 1-sigma coverage check: Mahalanobis distance <= 1.0 (or chi-square 2-DOF)
        cov = fit_res.stump_plane_cov
        diff = pstump_est - pstump_gt
        maha = float(diff.T @ np.linalg.pinv(cov) @ diff)
        # For 2-DOF, 1-sigma contour threshold is 2.30 (68.3% probability mass)
        if maha <= 2.30:
            stump_covered_1sigma += 1

        if (run_idx + 1) % 50 == 0 or run_idx == num_runs - 1:
            print(f"Run {run_idx+1:3d}/{num_runs}: "
                  f"Mean Bounce Err: {np.mean(bounce_errors_m)*100:4.1f} cm (max: {np.max(bounce_errors_m)*100:4.1f} cm), "
                  f"Mean Stump Err: {np.mean(stump_errors_m)*100:4.1f} cm (max: {np.max(stump_errors_m)*100:4.1f} cm), "
                  f"1-Sigma Coverage: {stump_covered_1sigma/(run_idx+1)*100:4.1f}%")

    print("\n---------------- FINAL BENCHMARK RESULTS ----------------")
    print(f"Total Deliveries Simulated:      {num_runs}")
    print(f"Bounce Point Mean Error:         {np.mean(bounce_errors_m)*100:.2f} cm (Target: < 10.0 cm)")
    print(f"Bounce Point 95th Percentile:    {np.percentile(bounce_errors_m, 95)*100:.2f} cm")
    print(f"Stump-Plane Mean Error:          {np.mean(stump_errors_m)*100:.2f} cm (Target: < 15.0 cm)")
    print(f"Stump-Plane 95th Percentile:     {np.percentile(stump_errors_m, 95)*100:.2f} cm")
    print(f"1-Sigma Truth Coverage:          {stump_covered_1sigma/num_runs*100:.1f}% (Expected: ~68.3%)")
    print("---------------------------------------------------------\n")


def generate_synthetic_demo(out_dir: str | Path = "demo_out"):
    """Generates synthetic delivery clip and runs end-to-end Hawk-Eye pipeline."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    video_path = out_dir / "synthetic_delivery.mp4"

    sim = SyntheticDeliverySimulator(DEFAULT_CONFIG, seed=42)
    sim_data = sim.simulate_delivery(
        speed_kmh=136.0,
        release_pos=(20.0, 0.10, 2.15),
        swing_accel=0.35,
        seam_kick=-0.60,
    )
    poses = sim.simulate_moving_camera_sequence(len(sim_data["timestamps"]))
    sim.render_synthetic_video_clip(sim_data, poses, video_path)

    canon = PitchLandmarks.get_canonical_3d_coordinates()
    landmarks_list = [PitchLandmarks(points_2d={k: tuple(poses[i].project(np.array(v).reshape(1,3))[0]) for k, v in canon.items()}) for i in range(len(poses))]

    class DemoPitchDetector:
        def __init__(self, lms): self.lms = lms; self.idx = 0
        def detect(self, f):
            lm = self.lms[min(self.idx, len(self.lms)-1)]
            self.idx += 1
            return lm

    gt_2d = [poses[i].project(p.reshape(1, 3))[0] for i, p in enumerate(sim_data["positions_3d"])]
    ball_det = SyntheticBallDetector(
        ground_truth_2d=[(float(p[0]), float(p[1])) for p in gt_2d],
        noise_sigma_px=0.5,
        drop_rate=0.08,
        num_false_positives=1,
    )

    # Run end-to-end pipeline
    result = run_pipeline(
        video_path=video_path,
        out_dir=out_dir,
        fps=50.0,
        handedness="right",
        speed_kmh=136.0,
        debug=True,
        ball_detector=ball_det,
        pitch_detector=DemoPitchDetector(landmarks_list),
    )
    print(f"Demo Run Finished! Result: {result}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", action="store_true", help="Run 200-delivery acceptance benchmark")
    parser.add_argument("--demo", action="store_true", help="Generate demo video and outputs")
    parser.add_argument("--out", type=str, default="demo_out", help="Output directory")
    args = parser.parse_args()

    if args.benchmark:
        run_synthetic_benchmark(num_runs=200)
    elif args.demo:
        generate_synthetic_demo(out_dir=args.out)
    else:
        run_synthetic_benchmark(num_runs=20)
